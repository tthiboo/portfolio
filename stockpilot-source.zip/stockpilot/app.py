"""Local demonstrator. No authentication, procurement or external integrations."""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
import hashlib
import json
import mimetypes
import sys
from engine import DEFAULT, LABELS, inputs, allocate, simulate, validate_assumptions

ROOT=Path(__file__).parent
PORT=8773
DATA=json.loads((ROOT/'data/cohort.json').read_text())
LOCK=json.loads((ROOT/'data/locked-models.json').read_text())
REPORT=json.loads((ROOT/'data/evaluation.json').read_text())
PROTOCOL=json.loads((ROOT/'protocol.json').read_text())
ORIGIN=DATA['meta']['weeks'].index(PROTOCOL['test_origins'][0])
for path,expected in [(ROOT/'data/cohort.json',LOCK['cohort_sha256']),
                      (ROOT/'protocol.json',LOCK['protocol_sha256']),
                      (ROOT/'data/locked-models.json',REPORT['locked_models_sha256'])]:
    if hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
        raise RuntimeError(f'Changed evaluation input: {path.name}. Rebuild explicitly.')

def calculate(body):
    if not isinstance(body,dict) or set(body)-{'assumptions','method','stock_overrides'}:
        raise ValueError('Unexpected request fields')
    a=validate_assumptions(body.get('assumptions',DEFAULT))
    method=body.get('method','selected')
    if method not in ('selected','seasonal52'):
        raise ValueError('Choose a supported policy')
    rows=inputs(DATA['items'],LOCK,ORIGIN,method,a)
    overrides=body.get('stock_overrides',{})
    valid={r['sku'] for r in rows}
    if not isinstance(overrides,dict) or set(overrides)-valid:
        raise ValueError('Unknown stock item')
    for r in rows:
        if r['sku'] in overrides:
            v=overrides[r['sku']]
            if isinstance(v,bool) or not isinstance(v,int) or not 0<=v<=1000000:
                raise ValueError('Stock override must be a whole number within 0..1000000')
            r['on_hand']=v
    plan=allocate(rows,a)
    # Per-SKU stock edits affect the one-run plan. Historical comparison uses identical
    # stock-weeks assumptions across policies and is clearly labelled separately.
    comparison={m:simulate(DATA['items'],LOCK,ORIGIN,ORIGIN+8,m,a) for m in ('selected','seasonal52')}
    return {'plan':plan,'comparison':comparison,'origin':DATA['meta']['weeks'][ORIGIN],
            'stock_overrides':overrides}

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass
    def reply(self,code,data,content='application/json; charset=utf-8'):
        if content.startswith('application/json'):
            data=json.dumps(data,allow_nan=False).encode()
        self.send_response(code)
        self.send_header('Content-Type',content)
        self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        self.end_headers(); self.wfile.write(data)
    def allowed(self):
        host=self.headers.get('Host','')
        accepted={f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}'}
        origin=self.headers.get('Origin')
        return host in accepted and (origin is None or origin in {f'http://{h}' for h in accepted})
    def do_GET(self):
        if not self.allowed(): return self.reply(403,{'error':'Local origin required'})
        path=urlparse(self.path).path
        if path=='/api/state':
            return self.reply(200,{'data':DATA,'report':REPORT,'protocol':PROTOCOL,'labels':LABELS,
                                  'default':DEFAULT, 'validation':LOCK['validation_mae'],
                                  'initial':calculate({})})
        if path=='/api/evaluation': return self.reply(200,REPORT)
        files={'/':'static/index.html','/app.js':'static/app.js','/style.css':'static/style.css',
               '/protocol.json':'protocol.json','/cohort.json':'data/cohort.json',
               '/locked-models.json':'data/locked-models.json'}
        if path not in files:return self.reply(404,{'error':'Not found'})
        target=ROOT/files[path]
        return self.reply(200,target.read_bytes(),mimetypes.guess_type(target.name)[0] or 'application/octet-stream')
    def do_POST(self):
        if not self.allowed(): return self.reply(403,{'error':'Local origin required'})
        if urlparse(self.path).path!='/api/plan':return self.reply(404,{'error':'Not found'})
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=8192: return self.reply(413,{'error':'Request size must be 1..8192 bytes'})
            if self.headers.get('Content-Type','').split(';')[0]!='application/json':
                return self.reply(415,{'error':'JSON required'})
            body=json.loads(self.rfile.read(length))
            return self.reply(200,calculate(body))
        except (ValueError,TypeError,KeyError) as e:
            return self.reply(400,{'error':str(e)})

if __name__=='__main__':
    port=int(sys.argv[1]) if len(sys.argv)>1 else PORT
    server=ThreadingHTTPServer(('127.0.0.1',port),Handler)
    print(f'StockPilot http://127.0.0.1:{port}',flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: server.server_close()
