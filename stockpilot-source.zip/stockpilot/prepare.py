"""Read the original workbook without editing it. Freeze the cohort from past data."""
from collections import Counter, defaultdict
from datetime import datetime, date, timedelta
from pathlib import Path
import hashlib
import json
import math
import re
import statistics
import time
import openpyxl

ROOT = Path(__file__).parent

def prepare():
    started = time.monotonic()
    protocol = json.loads((ROOT / 'protocol.json').read_text())
    start = date.fromisoformat(protocol['week_start'])
    end = date.fromisoformat(protocol['week_end'])
    cutoff = date.fromisoformat(protocol['selection_cutoff'])
    n = (end - start).days // 7 + 1
    t = (cutoff - start).days // 7
    source = ROOT / 'data/online_retail_II.xlsx'
    wb = openpyxl.load_workbook(source, read_only=True, data_only=True)
    weekly = defaultdict(lambda: [0] * n)
    names, prices = defaultdict(Counter), defaultdict(list)
    reasons, audit = Counter(), Counter()
    seen = set()
    sheets = []
    for ws in wb:
        it = ws.iter_rows(values_only=True)
        headers = next(it)
        sheets.append({'name': ws.title, 'headers': list(headers)})
        count = 0
        for row in it:
            if all(x is None for x in row):
                continue
            count += 1
            audit['source_rows'] += 1
            invoice, sku, description, qty, stamp, price, customer, country = row[:8]
            sku = str(sku).strip().upper()
            audit['missing_customer_rows'] += int(customer is None)
            audit['missing_description_rows'] += int(description is None)
            key = hashlib.blake2b(repr(row).encode(), digest_size=16).digest()
            if key in seen:
                audit['exact_repeated_rows_retained'] += 1
            seen.add(key)
            if not isinstance(stamp, datetime):
                reasons['invalid_date'] += 1
                continue
            if str(invoice).upper().startswith('C'):
                reasons['cancellation'] += 1
                if isinstance(qty, (int, float)):
                    audit['cancellation_absolute_units_all_countries'] += abs(qty)
                continue
            if not isinstance(qty, (int, float)) or not math.isfinite(qty) or qty <= 0 or qty != int(qty):
                reasons['nonpositive_or_invalid_quantity'] += 1
                continue
            if not isinstance(price, (int, float)) or not math.isfinite(price) or price <= 0:
                reasons['nonpositive_or_invalid_price'] += 1
                continue
            if country != protocol['country']:
                reasons['outside_uk'] += 1
                continue
            if not re.fullmatch(r'\d{5}[A-Z]?', sku):
                reasons['non_product_code'] += 1
                continue
            d = stamp.date()
            if d < start or d > end:
                reasons['partial_boundary_week'] += 1
                continue
            reasons['included'] += 1
            audit['included_gross_units'] += int(qty)
            i = (d - start).days // 7
            weekly[sku][i] += int(qty)
            if d < cutoff:
                if description:
                    names[sku][str(description).strip()] += 1
                prices[sku].append(float(price))
        sheets[-1]['rows'] = count
    wb.close()
    groups = {'frequent': [], 'intermittent': []}
    eligible = Counter()
    for sku, y in weekly.items():
        train = y[:t]
        positive = [i for i, v in enumerate(train) if v > 0]
        if len(positive) < 26 or t - positive[0] < 52:
            continue
        observed = train[positive[0]:]
        zero_rate = sum(v == 0 for v in observed) / len(observed)
        group = 'frequent' if zero_rate <= .20 else 'intermittent'
        eligible[group] += 1
        groups[group].append((sum(train), sku, zero_rate))
    items = []
    for group, candidates in groups.items():
        selected = sorted(candidates, key=lambda x: (-x[0], x[1]))[:12]
        if len(selected) != 12:
            raise ValueError(f'Insufficient eligible {group} SKUs; do not silently alter protocol')
        for units, sku, zr in selected:
            items.append({'sku': sku, 'name': names[sku].most_common(1)[0][0] if names[sku] else sku,
                          'segment': group, 'training_units': units, 'training_zero_rate': zr,
                          'training_median_sell_price': statistics.median(prices[sku]),
                          'weekly': weekly[sku]})
    assert sum(reasons.values()) == audit['source_rows']
    assert sum(map(sum, weekly.values())) == audit['included_gross_units']
    meta = {'citation': protocol['citation'], 'url': 'https://archive.ics.uci.edu/dataset/502/online+retail+ii',
            'sha256_workbook': hashlib.sha256(source.read_bytes()).hexdigest(),
            'sha256_protocol': hashlib.sha256((ROOT/'protocol.json').read_bytes()).hexdigest(),
            'sheets': sheets, 'audit': dict(audit), 'dispositions': dict(reasons),
            'universe_skus': len(weekly), 'eligible_skus': dict(eligible),
            'weeks': [(start + timedelta(weeks=i)).isoformat() for i in range(n)],
            'selection_cutoff_index': t, 'processing_seconds': round(time.monotonic()-started, 2)}
    (ROOT/'data/cohort.json').write_text(json.dumps({'meta': meta, 'items': items}, indent=2))
    print(json.dumps({'rows': audit['source_rows'], 'dispositions': dict(reasons),
                      'eligible': dict(eligible), 'cohort': len(items), 'weeks': n,
                      'seconds': meta['processing_seconds']}))

if __name__ == '__main__':
    prepare()
