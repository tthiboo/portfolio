"""Select and calibrate first; only then score the locked models on later periods."""
from pathlib import Path
import hashlib
import json
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from statistics import mean
from engine import MODELS, forecast, scale, quantile90, accuracy, simulate, DEFAULT

ROOT=Path(__file__).parent
def read():
    return json.loads((ROOT/'data/cohort.json').read_text()),json.loads((ROOT/'protocol.json').read_text())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def select():
    data,p=read()
    weeks=data['meta']['weeks']; items=data['items']
    selected, scores, scales = {}, {}, {}
    for item in items:
        sku,y=item['sku'],item['weekly']
        scales[sku]=scale(y[:data['meta']['selection_cutoff_index']])
        if not scales[sku]:
            raise ValueError('Constant series needs separately defined interval scale')
        model_scores={}
        for m in MODELS:
            errors=[]
            for d in p['validation_origins']:
                t=weeks.index(d)
                pred=forecast(y[:t],m)
                errors.extend(abs(a-f) for a,f in zip(y[t:t+4],pred))
            model_scores[m]=mean(errors)
        selected[sku]=min(MODELS,key=lambda m:model_scores[m])
        scores[sku]=model_scores
    pools=defaultdict(list)
    for policy in ('selected','seasonal52'):
        for item in items:
            sku,y,group=item['sku'],item['weekly'],item['segment']
            method=selected[sku] if policy=='selected' else policy
            for d in p['calibration_origins']:
                t=weeks.index(d)
                f=forecast(y[:t],method)
                for h in range(4):
                    pools[(policy,group,h)].append(abs(y[t+h]-f[h])/scales[sku])
    bands={}
    for policy in ('selected','seasonal52'):
        bands[policy]={i['sku']:[quantile90(pools[(policy,i['segment'],h)])*scales[i['sku']] for h in range(4)] for i in items}
    locked={'selected':selected, 'validation_mae':scores,'scales':scales,'bands':bands,
            'pool_counts':{f'{m}/{g}/h{h+1}':len(v) for (m,g,h),v in pools.items()},
            'cohort_sha256':sha(ROOT/'data/cohort.json'),'protocol_sha256':sha(ROOT/'protocol.json'),
            'locked_at_utc':datetime.now(timezone.utc).isoformat(), 'test_scored':False}
    (ROOT/'data/locked-models.json').write_text(json.dumps(locked,indent=2))
    print(json.dumps({'selected_methods':dict(Counter(selected.values())), 'test_accessed':False,
                      'lock_sha256':sha(ROOT/'data/locked-models.json')}))

def test():
    data,p=read(); locked=json.loads((ROOT/'data/locked-models.json').read_text())
    assert sha(ROOT/'data/cohort.json')==locked['cohort_sha256']
    assert sha(ROOT/'protocol.json')==locked['protocol_sha256']
    weeks=data['meta']['weeks']; items=data['items']
    records=[]
    for item in items:
        sku,y=item['sku'],item['weekly']
        row={'sku':sku,'name':item['name'],'segment':item['segment'], 'method':locked['selected'][sku]}
        for policy in ('selected',*MODELS):
            pred,actual,inside,bands=[],[],[],[]
            method=locked['selected'][sku] if policy=='selected' else policy
            for d in p['test_origins']:
                t=weeks.index(d); f=forecast(y[:t],method)
                for h in range(4):
                    band=locked['bands'][policy][sku][h] if policy in locked['bands'] else None
                    pred.append(f[h]); actual.append(y[t+h]); bands.append(band)
                    if band is not None:
                        inside.append(max(0,f[h]-band)<=y[t+h]<=f[h]+band)
            row[policy]={**accuracy(actual,pred,locked['scales'][sku]), 'coverage':mean(inside) if inside else None,
                         'mean_band_width':mean(min(f,b)+b for f,b in zip(pred,bands)) if inside else None,
                         'actual':actual,'predicted':pred,'band':bands}
        records.append(row)
    aggregates={}
    for group in ('all','frequent','intermittent'):
        rows=[r for r in records if group=='all' or r['segment']==group]
        aggregates[group]={}
        for policy in ('selected',*MODELS):
            actual=[v for r in rows for v in r[policy]['actual']]
            pred=[v for r in rows for v in r[policy]['predicted']]
            aggregates[group][policy]={**accuracy(actual,pred,0),
                                      'mase':mean(r[policy]['mase'] for r in rows),
                                      'coverage':mean(r[policy]['coverage'] for r in rows) if policy in locked['bands'] else None,
                                      'sku_count':len(rows),'observations':len(actual)}
    start=weeks.index(p['test_origins'][0]); stop=start+8
    sims={m:simulate(items,locked,start,stop,m,DEFAULT) for m in ('selected','seasonal52')}
    sensitivity=[]
    for lead in (0,1,3):
        for budget in (1000,5000,15000):
            a={**DEFAULT,'lead':lead,'budget':budget}
            sensitivity.append({'lead':lead,'budget':budget,**{m:simulate(items,locked,start,stop,m,a)['totals'] for m in ('selected','seasonal52')}})
    report={'created_at_utc':datetime.now(timezone.utc).isoformat(),
            'locked_models_sha256':sha(ROOT/'data/locked-models.json'),
            'test_start':weeks[start],'test_end':'2011-12-04', 'cohort':len(items),
            'observations':len(items)*8,'aggregates':aggregates,'items':records,
            'default_simulation':sims,'sensitivity':sensitivity,
            'selected_better_skus':sum(r['selected']['mae']<r['seasonal52']['mae'] for r in records),
            'selected_worse_skus':sum(r['selected']['mae']>r['seasonal52']['mae'] for r in records),
            'selected_tied_skus':sum(r['selected']['mae']==r['seasonal52']['mae'] for r in records)}
    (ROOT/'data/evaluation.json').write_text(json.dumps(report,indent=2,allow_nan=False))
    print(json.dumps({k:report[k] for k in ('aggregates','selected_better_skus','selected_worse_skus','selected_tied_skus')}))

if __name__=='__main__':
    {'select':select,'test':test}[sys.argv[1]]()
