# StockPilot

Local sales-forecasting and replenishment demonstrator by Mark Newton. Independent project, not a paid client engagement. Real historical sales; simulated inventory and procurement assumptions. No paid API.

## Run

Requires Python 3.10+. The app and tests use only the standard library. Open `Launch StockPilot.command`, or run `python3 app.py`, then visit http://127.0.0.1:8773/. Stop with Ctrl+C. Data extracts and measured results are included. No installation is needed for the app.

`python3 verify.py` runs the 23 checks, including a temporary loopback HTTP server. Results are written to `portfolio/verification.json` and `portfolio/test-results.txt`.

## Use

- Purchase plan: change budget, lead, packs or initial stock and apply. Select a product to inspect its target and edit its on-hand units. Export the calculated plan as CSV.
- Forecast review: inspect all candidates and each product. Group by training-defined sales frequency. Actuals, point forecasts and empirical bands stay visible together.
- Method & data: exclusive cleaning counts, chronology, assumptions and downloadable calculation records.

Input changes do not silently overwrite the displayed result: the button changes to **Apply changes**. Per-product stock overrides affect the one-run plan, not the historical policy comparison. Reset clears them. No supplier order is created.

## Data and licence

Chen, D. (2012). **Online Retail II**. UCI Machine Learning Repository. https://doi.org/10.24432/C5CG6D. [Source](https://archive.ics.uci.edu/dataset/502/online+retail+ii). [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

The original workbook contains 1,067,371 rows in two sheets. StockPilot derives UK weekly positive product sales and a training-selected cohort. Customer identifiers are not present in the delivered extract. Workbook SHA-256 and column names are recorded in `data/cohort.json`.

Exclusive dispositions, evaluated in this order, reconcile to every original row:

| Disposition | Rows |
|---|---:|
| Invalid date | 0 |
| Cancellation invoice | 19,494 |
| Nonpositive / invalid quantity | 3,457 |
| Nonpositive / invalid price | 2,750 |
| Outside UK | 83,169 |
| Non-product code | 3,771 |
| Partial boundary week | 29,816 |
| Included | 924,914 |

Product codes match five digits with an optional alphabetic suffix. Positive integer quantities and positive prices are required. Missing customer IDs are permitted. Original repeated rows are retained: without unique source line IDs, their origin cannot be established. The missing-value and repeated-row counts are in the audit record, not added as extra exclusion categories.

Cancellations are excluded from gross positive sales and counted separately. There is no reliable reconstruction of net demand, returned inventory or the original sale associated with each cancellation. No recorded sale in an observed complete week means zero **observed sales**. Stock availability and closures are unknown. Neither a zero sale nor a simulated shortage establishes real unmet demand.

The weekly window is Monday 7 December 2009 through Sunday 4 December 2011: 104 complete weeks. Partial first and last weeks are excluded.

## Evaluation protocol

`protocol.json` was recorded before scoring the final period. `data/locked-models.json` was written before the first test evaluation; its SHA-256 is recorded in `data/evaluation.json`. Model choices remain unchanged after reviewing test results.

| Stage | Information available |
|---|---|
| Cohort | Before 2 May 2011 |
| Model validation | Four 4-week origins: 2 May, 30 May, 27 June, 25 July |
| Band calibration | Four overlapping 4-week origins: 22 Aug, 29 Aug, 5 Sep, 12 Sep. Last target 9 Oct |
| Final test | Two 4-week origins: 10 Oct, 7 Nov. Last target 4 Dec |

Products need at least 26 nonzero training weeks and 52 weeks since the first recorded sale. Frequent means at most 20% zero weeks since first sale; intermittent means above 20%. Select the 12 highest training-unit-volume products in each segment, ties by SKU. This is a deliberately limited cohort, not a benchmark for all retail products or cold starts.

Five candidates: same week 52 weeks earlier; trailing eight-week mean; exponential level with alpha 0.3; last-year pattern multiplied by trailing-eight-week / equivalent-prior-year volume, clipped to 0.25..4; Croston SBA with alpha 0.1. No neural model, external signal or tuned hyperparameter search is used.

Per product, select the lowest mean absolute error across the four validation windows. Ties follow the declared model order. Forecasts fit only the prefix preceding each origin. Final method selection and bands remain frozen; the second test block may use sales observed during the first block. This is a two-block rolling evaluation, not a single eight-week forecast.

WAPE = sum absolute errors / sum observed units. Bias = (forecast units - observed units) / observed units. WAPE and bias are undefined for zero observed totals and remain null. MASE divides per-product MAE by its fixed early-training one-week naive MAE, then averages products equally. MASE below one compares to that training scale, not a guaranteed win over a test-period naive method. No denominator is calculated using future data.

Bands use absolute validation-selected forecast errors from the later calibration window, normalized by fixed early-training naive MAE, pooled by segment and forecast horizon. There are 48 calibration errors per segment/horizon/policy. Radius uses the sorted finite-sample 90% order statistic and clips the lower endpoint to zero. Calibration origins overlap and time-series errors are dependent: these are empirical error bands, not a finite-sample coverage guarantee. Extra fixed candidates are scored for transparency only; no bands were retroactively fitted for them.

## Measured final results

24 products, 192 product-weeks, 98,173 observed units.

| Method | WAPE | Bias | Mean product MASE |
|---|---:|---:|---:|
| Validation-selected | 67.6% | -4.6% | 1.315 |
| Same week last year | 119.0% | +63.1% | 1.718 |
| Trailing 8-week mean | 65.3% | -28.0% | 1.296 |
| Smoothed level | 66.5% | -20.3% | 1.235 |
| Scaled annual pattern | 82.0% | +13.7% | 1.299 |
| Croston SBA | 69.3% | -32.5% | 1.464 |

The simple mean has lower aggregate WAPE than per-product selection. There is no universal winner. Against the last-year baseline, selection wins on 15 products, loses on four, and ties on five. Three products have zero recorded test sales; their WAPE is null. Selected WAPE by segment: frequent 61.2%, intermittent 80.3%. Nominal 90% bands cover 165/192 observations (85.9%). Wholesale bursts and changing availability limit predictive accuracy. All product-level results are included.

## Inventory policy

One warehouse, weekly review, integer-week lead 0..3, lost sales, no starting pipeline, no returns or supplier capacity limits. Synthetic cost per product is 50% of its **early-training** median selling price, rounded half up to GBP cents and at least one penny. Initial stock is trailing-eight-week mean sales at the simulation start times the stock-weeks input, rounded to whole units.

At the end of week t, forecast the next lead+1 weeks using only sales through t. Target = sum forecasts over that protection period + optional sum of calibrated weekly band radii. Inventory position = on hand + all outstanding orders. Request a positive target shortfall rounded up to packs. Allocate whole packs greedily by lowest on-hand stock coverage, then highest pre-arrival gap, then SKU. Skip a pack when remaining budget cannot buy it and continue to other products. This heuristic is not an optimal knapsack or service-level optimizer.

End-of-week orders arrive at the **start** of week t+lead+1. Even zero full-week lead delivers next week, not earlier in the current week. On arrival, serve that week's observed units, record unmet scenario units and end stock, then place a new order. Each weekly run has a separate budget. Inventory and served-unit conservation are tested.

Products with no observed sales in the preceding eight weeks carry an **inactivity review** flag. Availability or retirement is unknown. The replay mechanically accepts funded proposals and does not simulate a human rejecting a flagged product. A real implementation needs lifecycle and availability inputs; do not automatically procure from this demo.

Synthetic weekly holding charge = 0.5% of ending stock value. Synthetic unmet-unit penalty = twice simulated unit cost. Scenario charge = purchase cost + holding + unmet penalty. Purchase cost includes outstanding end-of-test orders. Ending inventory receives no resale credit. This is not economic profit or an unbiased lifetime cost comparison. Pending and ending units are reported separately. Initial stock is common and its acquisition cost is omitted in both policies.

Default assumptions: GBP 5,000 per run, one full-week lead, pack 12, two weeks initial stock, buffer on. Observed units served: selected 46.1%, last-year 42.7%. Average end stock: 12,092 versus 21,030 units. Both purchase roughly GBP 40,000 over eight runs. A strict budget and conservative pooled buffers leave substantial simulated unmet sales. These are scenario outcomes, not measured customer losses or savings. Nine fixed budget/lead sensitivity scenarios are stored in the evaluation file.

## Reproduce from the original workbook

Optional build dependencies: openpyxl for reading the workbook, reportlab for the one-page PDF. Install `requirements.txt` only when rebuilding these artifacts. The app itself needs neither.

1. Download https://archive.ics.uci.edu/static/public/502/online+retail+ii.zip and extract `online_retail_II.xlsx` into `data/`.
2. Run `python3 prepare.py` to recreate the weekly extract and audit.
3. Run `python3 evaluate.py select` to select methods and calibrate bands. This records a new lock timestamp and hash.
4. Run `python3 evaluate.py test` to score the later periods and both inventory policies.
5. Run `python3 verify.py`, then `python3 app.py`.

Regeneration overwrites the corresponding generated files. Numeric results should reproduce with the same source and protocol; timestamps, processing duration and associated file hashes change. Preserve the shipped lock and evaluation if auditing this original run. The app checks extract, protocol and model-lock hashes before starting.

## Scope and packaging

Standard-library Python HTTP server, deterministic forecasts, browser SVG charts. No production authentication, user accounts, ERP adapter, supplier ordering or long-running parsing service. Bound to loopback with Host/Origin checks. It is intended for local review, not public Internet deployment. Scenario edits are session-only. Forecast evaluation is immutable in the interface.

Portfolio files: English/Russian case copy, one-page PDF, actual UI screenshots, measured tests, derived weekly series and model records. The 72-second video is a montage of actual browser screenshots, not a continuous screen recording. The source archive excludes the raw workbook, download ZIP, bytecode and the archive itself. Derived data attribution is retained.

Commercial scope demonstrated: sales-data assessment, forecast evaluation, a stock-planning prototype, then client-specific integrations and workflow. Production use requires current client data, availability/lifecycle records, real cost and lead history, authentication and operational acceptance tests.

Method references: [Forecast accuracy](https://otexts.com/fpp3/accuracy.html), [rolling-origin validation](https://otexts.com/fpp3/tscv.html), Hyndman & Athanasopoulos, Forecasting: Principles and Practice, third edition.


## Interface

The default view is a forecast atlas: a row-normalized, eight-week observed-sales map linked to the product chart. Hover for exact cell counts; accessible product labels also contain those counts. The purchase plan uses a horizontal constraint toolbar.
