"""One-page portfolio artifact from actual measurements and a real browser capture."""
from pathlib import Path
import json
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import ImageReader

ROOT=Path(__file__).parent
def build():
    tests=json.loads((ROOT/'portfolio/verification.json').read_text())
    report=json.loads((ROOT/'data/evaluation.json').read_text())
    meta=json.loads((ROOT/'data/cohort.json').read_text())['meta']
    assert tests['passed']
    out=ROOT/'output/pdf/stockpilot-case.pdf';out.parent.mkdir(parents=True,exist_ok=True)
    c=canvas.Canvas(str(out),pagesize=A4)
    c.setTitle('StockPilot - Sales forecasting and replenishment simulator')
    c.setAuthor('Mark Newton')
    W,H=A4;ink=HexColor('#13253a');muted=HexColor('#5b6673');paper=HexColor('#f2f4f4');orange=HexColor('#f05a2b')
    c.setFillColor(paper);c.rect(0,0,W,H,fill=1,stroke=0)
    c.setFillColor(ink);c.setFont('Helvetica-Bold',9);c.drawString(40,799,'MARK NEWTON / INDEPENDENT ENGINEERING')
    c.setFont('Times-Roman',38);c.drawString(40,746,'StockPilot')
    c.setFont('Helvetica',13);c.drawString(40,719,'Sales forecasting and replenishment simulator.')
    cards=[(str(report['cohort']),'PRODUCTS'),(str(len(meta['weeks'])),'HISTORICAL WEEKS'),(str(tests['tests_run']),'AUTOMATED CHECKS')]
    for i,(value,label) in enumerate(cards):
        x=40+i*175;c.setStrokeColor(HexColor('#c7d0d5'));c.line(x,682,x+165,682)
        c.setFillColor(ink);c.setFont('Times-Roman',26);c.drawString(x+14,652,value)
        c.setFont('Helvetica',8);c.drawString(x+14,636,label)
    c.drawImage(ImageReader(str(ROOT/'portfolio/03-forecast-review.jpg')),40,305,width=515,height=289.6875,preserveAspectRatio=True,mask='auto')
    c.setFillColor(muted);c.setFont('Helvetica',8);c.drawString(40,289,'Actual local demo. Locked forecasts, observed sales and calibrated error bands.')
    a=report['aggregates']['all']
    columns=[(40,'WHAT THE TOOL DOES',[
        'Five fixed forecasting methods.',
        'Weekly purchase budgets and whole-pack orders.',
        'Editable stock with an explained calculation.',
        'Product-level errors and inactivity review flags.']),
        (314,'WHAT THE FINAL TEST SHOWS',[
        f"{report['observations']} product-weeks, 10 Oct - 4 Dec 2011.",
        f"WAPE: selected {a['selected']['wape']*100:.1f}%; mean {a['mean8']['wape']*100:.1f}%.",
        f"Last-year baseline {a['seasonal52']['wape']*100:.1f}%; 4 losing SKUs.",
        f"90% band: {a['selected']['coverage']*100:.1f}% empirical coverage."])]
    for x,title,lines in columns:
        c.setFillColor(ink);c.setFont('Helvetica-Bold',9);c.drawString(x,258,title)
        c.setFillColor(muted);c.setFont('Helvetica',8.5)
        for i,line in enumerate(lines):c.drawString(x,235-19*i,line)
    c.setStrokeColor(HexColor('#d3d5cf'));c.line(40,132,555,132)
    c.setFillColor(ink);c.setFont('Helvetica-Bold',9);c.drawString(40,111,'Python / Time series / Inventory simulation / HTTP APIs / JavaScript')
    c.setFillColor(muted);c.setFont('Helvetica',8)
    c.drawString(40,91,'Real historical sales. Stock, costs and lead times are simulated. No client deployment.')
    c.drawString(40,75,'The simple mean beats model selection on aggregate test WAPE. No accuracy guarantee.')
    c.drawString(40,56,'Source: Chen, D. (2012). Online Retail II, UCI. CC BY 4.0. doi:10.24432/C5CG6D')
    c.linkURL('https://doi.org/10.24432/C5CG6D',(40,51,555,64),relative=0)
    c.save();print(out)

if __name__=='__main__':build()
