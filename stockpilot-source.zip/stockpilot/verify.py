from pathlib import Path
from datetime import datetime, timezone
import json
import platform
import time
import unittest
import io

root=Path(__file__).parent
started=time.monotonic();log=io.StringIO()
suite=unittest.defaultTestLoader.discover(str(root),pattern='test_stockpilot.py')
result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
(root/'portfolio/test-results.txt').write_text(log.getvalue())
summary={'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
         'passed':result.wasSuccessful(),'seconds':round(time.monotonic()-started,3),
         'python':platform.python_version(),'platform':platform.platform(),
         'at_utc':datetime.now(timezone.utc).isoformat()}
(root/'portfolio/verification.json').write_text(json.dumps(summary,indent=2))
print(log.getvalue());print(json.dumps(summary))
raise SystemExit(0 if result.wasSuccessful() else 1)
