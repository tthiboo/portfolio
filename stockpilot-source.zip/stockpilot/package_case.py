from pathlib import Path
from hashlib import sha256
from decimal import Decimal
import csv
import json
import shutil
import sys
import zipfile

root=Path(__file__).parent
portfolio=root/'portfolio'
shots=['03-forecast-review.jpg','04-zero-sales.jpg','06-data-protocol.jpg',
       '01-purchase-plan.jpg','02-explained-order.jpg','07-simulation.jpg']
lines=[]
for s in shots:
    assert (portfolio/s).is_file()
    lines += [f"file '{s}'",'duration 12']
lines += [f"file '{shots[-1]}'"]
(portfolio/'walkthrough-frames.txt').write_text('\n'.join(lines)+'\n')
shutil.copyfile(portfolio/'03-forecast-review.jpg',portfolio/'stockpilot-cover.jpg')
export=Path(sys.argv[2]) if len(sys.argv)>2 and sys.argv[1]=='export' else None
if export is not None and export.exists():
    rows=list(csv.DictReader(export.open()))
    assert len(rows)==24
    spend=sum(Decimal(r['cost_GBP']) for r in rows)
    assert spend<=Decimal(rows[0]['weekly_budget_GBP'])
    assert all(int(r['funded_units'])%int(r['pack_units'])==0 for r in rows)
    shutil.copyfile(export,portfolio/'example-purchase-plan.csv')
    (portfolio/'export-verification.json').write_text(json.dumps({'rows':len(rows),'spend_GBP':str(spend),
        'budget_GBP':rows[0]['weekly_budget_GBP'],'lead_weeks':int(rows[0]['lead_weeks']),
        'whole_packs':True,'captured_from':'Browser CSV download. Synthetic inventory inputs.'},indent=2))

def archive():
    excluded={'uci-online-retail-ii.zip','online_retail_II.xlsx','stockpilot-source.zip'}
    files=sorted(p for p in root.rglob('*') if p.is_file() and p.name not in excluded
                 and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.db'))
    manifest={str(p.relative_to(root)):sha256(p.read_bytes()).hexdigest() for p in files if p.name!='source-manifest.json'}
    (portfolio/'source-manifest.json').write_text(json.dumps(manifest,indent=2))
    if portfolio/'source-manifest.json' not in files:files.append(portfolio/'source-manifest.json')
    out=portfolio/'stockpilot-source.zip'
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        for p in files:z.write(p,Path('stockpilot')/p.relative_to(root))
    with zipfile.ZipFile(out) as z:
        assert z.testzip() is None
        assert not any('online_retail_II.xlsx' in n or '__pycache__' in n for n in z.namelist())
        print(json.dumps({'archive':str(out),'files':len(z.namelist()),'bytes':out.stat().st_size}))

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='archive':archive()
