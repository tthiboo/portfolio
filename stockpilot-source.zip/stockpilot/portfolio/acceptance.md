# Acceptance record

Independent portfolio demonstration. This maps the original project brief to implemented evidence; it is not client acceptance.

| Requirement | Evidence |
|---|---|
| Real sales and visible inventory assumptions | UCI attribution, workbook hash, source disposition audit, editable scenario controls |
| No future information in selection or forecasts | Frozen protocol, selection record, period-separation and prefix tests |
| Final period kept out of model selection | Lock timestamp and hash precede first final-test scoring. Selections reproduce using only validation windows |
| Missing/zero sales distinguished, cancellations explicit | README cleaning definitions. Zero-total WAPE remains null. Returns not treated as reconstructed demand |
| Metrics by product group and product | Both segments, all 24 products and all five candidates included in UI and evaluation JSON |
| Simple baseline and losing cases | Annual baseline plus simple mean. Four products lose to annual baseline; mean has lower aggregate WAPE than selected methods |
| Calibrated uncertainty with measured coverage | 48 calibration errors per segment/horizon. Test coverage 165/192. Overlap/dependence limitations published |
| Explainable and editable purchase decisions | Target decomposition, whole-pack allocation, per-SKU stock edits, CSV export. No automatic supplier orders |
| Budget/lead sensitivity on common assumptions | Nine fixed scenarios in evaluation JSON. UI recalculation and unit conservation checked |
| Reproducible implementation and polished interface | 23 passing automated checks. Real browser actions verified. 390px mobile layouts have no page overflow. Responsive chart labels, console warnings/errors empty |

Extra review detail: inactivity flags use the previous eight weeks only. Pending inventory and end stock stay separate. This avoids presenting a simulated purchase charge as real profit or customer savings.

Materials: original source, derived cohort, model lock, results, tests, actual browser captures, one-page PDF, and a 72-second screenshot montage. Raw workbook/customer identifiers are excluded from the shareable archive.
