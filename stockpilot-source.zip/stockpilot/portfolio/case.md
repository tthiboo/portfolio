# StockPilot

**Sales forecasting and replenishment simulator. Independent project.**

Convert sales history into a purchase plan with visible assumptions: how much to order, what the budget funds, and where the forecast is unreliable.

- Real UCI retail transactions. 24 products selected using past data only.
- Five fixed forecasting methods. Separate validation, calibration and final test.
- Budget, lead time, pack size and stock inputs recalculate the plan.
- Each order opens into expected sales, error buffer, stock position and whole-pack allocation.
- Product-level errors, zero-sale products and inactivity review flags remain visible.

**Verification:** 23 automated checks. 192 product-weeks in the final test. Selected WAPE 67.6%; last-year baseline 119.0%; simple eight-week mean 65.3%. The simple mean has lower aggregate test error. Selection beats the annual baseline on 15 products, loses on four and ties on five. Nominal 90% bands cover 85.9% of test observations.

**Scope:** real historical sales, simulated stock/cost/lead assumptions. Local demonstrator. No paid client, automatic procurement, measured customer savings or guaranteed forecast accuracy.

**Stack:** Python, time-series evaluation, inventory simulation, HTTP APIs, JavaScript, responsive SVG charts. No paid model API.

**Service:** assess sales data, establish forecasting baselines, test methods on history, and build an auditable replenishment prototype before integrating with the client's systems.

Source: Chen, D. (2012). Online Retail II. UCI Machine Learning Repository. https://doi.org/10.24432/C5CG6D. CC BY 4.0. Weekly aggregation and training-selected cohort are derived from the source dataset.

---

## Русская карточка

**StockPilot — прогноз продаж и планирование закупок. Самостоятельный проект.**

Приложение рассчитывает закупку по истории продаж, бюджету, сроку поставки, упаковке и заданным остаткам. Каждая позиция раскрывается до расчёта. Данные реальные: исторические транзакции UCI. Остатки, себестоимость и условия поставки заданы как допущения симулятора.

Пять методов прогнозирования. Раздельные периоды выбора модели, калибровки и финальной проверки. 24 товара, 192 товаро-недели в тесте. Все ошибки и слабые товары показаны. Простое среднее оказалось точнее выбора модели по суммарному WAPE — результат сохранён без подгонки. 23 автоматические проверки прошли.

Кейс подтверждает оценку данных, проверку прогнозов и разработку прототипа закупок. Это демонстрация, не оплаченный клиентский проект и не обещание финансового результата.


## Interface

The default view is a forecast atlas: a row-normalized, eight-week observed-sales map linked to the product chart. Hover for exact cell counts; accessible product labels also contain those counts. The purchase plan uses a horizontal constraint toolbar.
