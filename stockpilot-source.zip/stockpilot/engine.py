"""Small transparent forecasting and inventory policies. No paid APIs."""
from decimal import Decimal, ROUND_HALF_UP
from math import ceil, isfinite
from statistics import mean

MODELS = ('seasonal52', 'mean8', 'level03', 'seasonal_scaled', 'croston_sba')
LABELS = {'seasonal52': 'Same week last year', 'mean8': 'Trailing 8-week mean',
          'level03': 'Smoothed level (0.3)', 'seasonal_scaled': 'Scaled annual pattern',
          'croston_sba': 'Croston SBA (0.1)', 'selected': 'Validation-selected'}

def forecast(history, method, horizon=4):
    y = [float(x) for x in history]
    if not y or any(not isfinite(x) or x < 0 for x in y):
        raise ValueError('Sales history must contain finite nonnegative observations')
    if method not in MODELS or not isinstance(horizon, int) or not 1 <= horizon <= 4:
        raise ValueError('Unsupported method or horizon')
    if method in ('seasonal52', 'seasonal_scaled'):
        if len(y) < 52:
            raise ValueError('Annual baseline requires 52 weeks')
        f = y[-52:-52+horizon] if horizon < 52 else y[-52:]
        if method == 'seasonal_scaled':
            past = sum(y[-60:-52]) if len(y) >= 60 else 0
            ratio = min(4., max(.25, sum(y[-8:])/past)) if past else 1.
            f = [x*ratio for x in f]
        return f
    if method == 'mean8':
        return [mean(y[-8:])] * horizon
    if method == 'level03':
        level = y[0]
        for x in y[1:]:
            level = .3*x + .7*level
        return [level] * horizon
    positive = [i for i, x in enumerate(y) if x > 0]
    if not positive:
        return [0.] * horizon
    first = positive[0]
    size, interval, elapsed = y[first], float(first+1), 0
    for x in y[first+1:]:
        elapsed += 1
        if x > 0:
            size = .1*x + .9*size
            interval = .1*elapsed + .9*interval
            elapsed = 0
    return [.95*size/interval] * horizon

def scale(history):
    return mean(abs(b-a) for a,b in zip(history, history[1:])) if len(history)>1 else 0.

def quantile90(values):
    if not values:
        raise ValueError('Calibration observations are required')
    values = sorted(values)
    return values[min(len(values)-1, ceil(.9*(len(values)+1))-1)]

def accuracy(actual, predicted, denominator):
    if len(actual) != len(predicted) or not actual:
        raise ValueError('Aligned nonempty vectors required')
    ae = sum(abs(a-p) for a,p in zip(actual, predicted))
    units = sum(actual)
    return {'wape': ae/units if units else None,
            'bias': (sum(predicted)-units)/units if units else None,
            'mase': ae/len(actual)/denominator if denominator else None,
            'mae': ae/len(actual), 'actual_units': units,
            'forecast_units': sum(predicted), 'absolute_error_units': ae}

def cents(value):
    return int((Decimal(str(value))*100).quantize(Decimal('1'), rounding=ROUND_HALF_UP))

def validate_assumptions(a):
    fields = {'lead': (0,3), 'pack': (1,100), 'budget': (0,100000),
              'stock_weeks': (0,8), 'buffer': (0,1)}
    if set(a) != set(fields):
        raise ValueError('Required assumptions: lead, pack, budget, stock_weeks, buffer')
    for key,(low,high) in fields.items():
        v = a[key]
        if isinstance(v,bool) or not isinstance(v,(int,float)) or not isfinite(v) or not low <= v <= high:
            raise ValueError(f'{key} must be within {low}..{high}')
    if int(a['lead']) != a['lead'] or int(a['pack']) != a['pack']:
        raise ValueError('Lead and pack must be whole numbers')
    if Decimal(str(a['budget'])) != Decimal(cents(a['budget']))/100:
        raise ValueError('Budget must have at most two decimal places')
    return {**a, 'lead': int(a['lead']), 'pack': int(a['pack'])}

DEFAULT = {'lead': 1, 'pack': 12, 'budget': 5000, 'stock_weeks': 2, 'buffer': 1}

def allocate(rows, assumptions):
    """Coverage-first greedy whole-pack allocation. Not an optimal knapsack solver."""
    a = validate_assumptions(assumptions)
    remaining = cents(a['budget'])
    result = []
    for row in rows:
        f, band = row['forecast'], row['band']
        protect = a['lead']+1
        expected = sum(f[:protect])
        buffer = a['buffer']*sum(band[:protect])
        position = row['on_hand']+row.get('on_order',0)
        desired = max(0, ceil((expected+buffer-position)/a['pack']))*a['pack']
        weekly = max(mean(f),1e-9)
        cover = row['on_hand']/weekly
        before = sum(f[:a['lead']])
        result.append({**row, 'target': expected+buffer, 'expected': expected,
                       'buffer_units': buffer, 'desired': desired, 'cover_weeks': cover,
                       'prearrival_gap': max(0, before-row['on_hand'])})
    result.sort(key=lambda r:(r['cover_weeks'], -r['prearrival_gap'], r['sku']))
    for r in result:
        pack_cost = r['cost_cents']*a['pack']
        qty = min(r['desired']//a['pack'], remaining//pack_cost)*a['pack']
        r['order_units'] = qty
        r['order_cost_cents'] = qty*r['cost_cents']
        r['deferred_units'] = r['desired']-qty
        remaining -= r['order_cost_cents']
    assert remaining >= 0
    return {'rows': result, 'spend_cents': cents(a['budget'])-remaining,
            'unspent_cents': remaining, 'assumptions': a}

def inputs(items, locked, origin, method, assumptions, on_hand=None, pipeline=None):
    a = validate_assumptions(assumptions)
    if method not in ('selected','seasonal52'):
        raise ValueError('Unsupported policy')
    out = []
    for item in items:
        sku = item['sku']
        hist = item['weekly'][:origin]
        chosen = locked['selected'][sku] if method == 'selected' else 'seasonal52'
        f = forecast(hist, chosen)
        band = locked['bands'][method][sku]
        cost = max(1,cents(item['training_median_sell_price']*.5))
        stock = round(mean(hist[-8:])*a['stock_weeks']) if on_hand is None else on_hand[sku]
        pending = 0 if pipeline is None else sum(q for due,s,q in pipeline if s == sku)
        out.append({'sku':sku, 'name':item['name'], 'segment':item['segment'],
                    'method':chosen, 'forecast':f, 'band':band,
                    'on_hand':stock, 'on_order':pending, 'cost_cents':cost,
                    'inactive_review':sum(hist[-8:])==0})
    return out

def simulate(items, locked, start, stop, method, assumptions):
    if method not in ('selected','seasonal52'):
        raise ValueError('Unsupported policy')
    a = validate_assumptions(assumptions)
    stock = {r['sku']:r['on_hand'] for r in inputs(items,locked,start,method,a)}
    initial = stock.copy()
    pipeline, log = [], []
    totals = {'observed_units':0, 'served_units':0, 'unmet_units':0,
              'order_cost_cents':0, 'holding_cost_cents':0, 'unmet_penalty_cents':0,
              'orders':0, 'stock_unit_weeks':0, 'initial_units':sum(initial.values()),
              'received_units':0}
    costs = {i['sku']:max(1,cents(i['training_median_sell_price']*.5)) for i in items}
    for w in range(start,stop):
        arriving = [p for p in pipeline if p[0] == w]
        pipeline = [p for p in pipeline if p[0] != w]
        for due,sku,qty in arriving:
            stock[sku] += qty
            totals['received_units'] += qty
        demand, served, unmet = 0,0,0
        for i in items:
            sku, sale = i['sku'], i['weekly'][w]
            fill = min(sale,stock[sku])
            gap = sale-fill
            stock[sku] -= fill
            demand += sale; served += fill; unmet += gap
            totals['unmet_penalty_cents'] += gap*costs[sku]*2
            totals['holding_cost_cents'] += int((Decimal(stock[sku]*costs[sku])*Decimal('.005')).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
        order = allocate(inputs(items,locked,w+1,method,a,stock,pipeline),a)
        for r in order['rows']:
            if r['order_units']:
                pipeline.append((w+a['lead']+1,r['sku'],r['order_units']))
                totals['orders'] += 1
        totals['observed_units'] += demand
        totals['served_units'] += served
        totals['unmet_units'] += unmet
        totals['order_cost_cents'] += order['spend_cents']
        totals['stock_unit_weeks'] += sum(stock.values())
        log.append({'week_index':w,'observed':demand,'served':served,'unmet':unmet,
                    'ending_stock':sum(stock.values()), 'spend_cents':order['spend_cents'],
                    'arrivals':sum(q for _,_,q in arriving)})
    totals['fill_rate'] = totals['served_units']/totals['observed_units'] if totals['observed_units'] else None
    totals['average_end_stock'] = totals['stock_unit_weeks']/(stop-start)
    totals['ending_stock'] = sum(stock.values())
    totals['pending_units'] = sum(q for _,_,q in pipeline)
    totals['scenario_charge_cents'] = totals['order_cost_cents']+totals['holding_cost_cents']+totals['unmet_penalty_cents']
    assert totals['initial_units']+totals['received_units']-totals['served_units']==totals['ending_stock']
    assert totals['served_units']+totals['unmet_units']==totals['observed_units']
    return {'totals':totals, 'weeks':log, 'assumptions':a, 'method':method}
