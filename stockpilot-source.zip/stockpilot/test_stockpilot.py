from copy import deepcopy
from hashlib import sha256
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer
from statistics import mean
from threading import Thread
import json
import math
import unittest
from engine import forecast, accuracy, scale, quantile90, allocate, inputs, simulate, DEFAULT, MODELS
import app

class ForecastTests(unittest.TestCase):
    def test_annual_horizon_alignment(self):
        history=list(range(60))
        self.assertEqual(forecast(history,'seasonal52'),[8.,9.,10.,11.])
        self.assertEqual(forecast([10]*52,'seasonal_scaled'),[10]*4)
        with self.assertRaises(ValueError): forecast([1]*51,'seasonal52')
    def test_simple_level_and_mean(self):
        self.assertEqual(forecast([100]*10+[0]*8,'mean8'),[0]*4)
        self.assertEqual(forecast([10,20],'level03'),[13]*4)
        self.assertEqual(forecast([0]*60,'croston_sba'),[0]*4)
        self.assertEqual(forecast([10]*60,'croston_sba'),[9.5]*4)
    def test_reject_unknown_negative_nonfinite(self):
        for history,method,h in [([], 'mean8',4),([1,-1],'mean8',4),([math.nan],'mean8',4),([1],'magic',4),([1],'mean8',5)]:
            with self.subTest(history=history):
                with self.assertRaises(ValueError):forecast(history,method,h)
    def test_zero_metrics_are_not_fake_accuracy(self):
        m=accuracy([0,0],[2,3],0)
        self.assertIsNone(m['wape']); self.assertIsNone(m['bias']); self.assertIsNone(m['mase'])
        self.assertEqual(m['mae'],2.5)
    def test_metric_definitions(self):
        m=accuracy([10,20],[12,16],2)
        self.assertAlmostEqual(m['wape'],.2);self.assertAlmostEqual(m['bias'],-2/30)
        self.assertEqual(m['mase'],1.5)
        self.assertEqual(scale([1,4,2]),2.5)
        self.assertEqual(quantile90(list(range(48))),44)
    def test_future_sales_do_not_change_forecast_inputs(self):
        for item in app.DATA['items']:
            original=item['weekly'];changed=original[:app.ORIGIN]+[999999]*8
            for method in MODELS:
                self.assertEqual(forecast(original[:app.ORIGIN],method),forecast(changed[:app.ORIGIN],method))

class ProtocolTests(unittest.TestCase):
    def test_periods_do_not_cross_selection_calibration_test(self):
        weeks=app.DATA['meta']['weeks'];p=app.PROTOCOL
        last_validation=max(weeks.index(d)+3 for d in p['validation_origins'])
        first_cal=min(weeks.index(d) for d in p['calibration_origins'])
        last_cal=max(weeks.index(d)+3 for d in p['calibration_origins'])
        self.assertLess(last_validation,first_cal);self.assertLess(last_cal,app.ORIGIN)
        self.assertEqual(len(weeks)-app.ORIGIN,8)
    def test_model_selection_reproduces_from_validation_only(self):
        weeks=app.DATA['meta']['weeks']
        for item in app.DATA['items']:
            independent={}
            for method in MODELS:
                errors=[]
                for d in app.PROTOCOL['validation_origins']:
                    t=weeks.index(d);actual=item['weekly'][t:t+4]
                    pred=forecast(item['weekly'][:t],method)
                    errors.extend(abs(a-f) for a,f in zip(actual,pred))
                independent[method]=mean(errors)
            self.assertEqual(min(MODELS,key=lambda m:independent[m]),app.LOCK['selected'][item['sku']])
    def test_frozen_files_match_evaluation_hashes(self):
        self.assertEqual(sha256((app.ROOT/'data/locked-models.json').read_bytes()).hexdigest(),app.REPORT['locked_models_sha256'])
        self.assertEqual(sha256((app.ROOT/'protocol.json').read_bytes()).hexdigest(),app.LOCK['protocol_sha256'])
    def test_source_dispositions_reconcile_and_segments_exist(self):
        m=app.DATA['meta']
        self.assertEqual(sum(m['dispositions'].values()),m['audit']['source_rows'])
        self.assertEqual(sum(s['rows'] for s in m['sheets']),1067371)
        self.assertEqual(m['audit']['source_rows'],1067371)
        self.assertEqual(sum(i['segment']=='frequent' for i in app.DATA['items']),12)
        self.assertEqual(sum(i['segment']=='intermittent' for i in app.DATA['items']),12)
    def test_report_metrics_reconcile_independently(self):
        for group in ('all','frequent','intermittent'):
            rows=[r for r in app.REPORT['items'] if group=='all' or r['segment']==group]
            for policy in ('selected',*MODELS):
                actual=sum(sum(r[policy]['actual']) for r in rows)
                error=sum(sum(abs(a-f) for a,f in zip(r[policy]['actual'],r[policy]['predicted'])) for r in rows)
                self.assertAlmostEqual(error/actual,app.REPORT['aggregates'][group][policy]['wape'])
    def test_coverage_and_losing_skus_are_reported(self):
        covered=0
        for r in app.REPORT['items']:
            for a,p,b in zip(r['selected']['actual'],r['selected']['predicted'],r['selected']['band']):
                covered+=max(0,p-b)<=a<=p+b
        self.assertEqual(covered,165)
        self.assertEqual(app.REPORT['observations'],192)
        self.assertEqual(app.REPORT['selected_worse_skus'],4)

class PlanningTests(unittest.TestCase):
    def row(self,sku='A',cost=100,stock=0):
        return {'sku':sku,'name':sku,'on_hand':stock,'on_order':0,'forecast':[10]*4,'band':[0]*4,'cost_cents':cost}
    def test_budget_and_pack_rounding(self):
        p=allocate([self.row('A'),self.row('B',cost=200)],{**DEFAULT,'pack':12,'budget':30,'buffer':0})
        self.assertLessEqual(p['spend_cents'],3000)
        self.assertEqual(p['spend_cents']+p['unspent_cents'],3000)
        self.assertTrue(all(r['order_units']%12==0 for r in p['rows']))
        self.assertEqual(p['rows'][0]['desired'],24)
    def test_zero_budget_and_zero_stock_override(self):
        p=app.calculate({'assumptions':{**DEFAULT,'budget':0},'stock_overrides':{'84077':0}})['plan']
        self.assertEqual(p['spend_cents'],0)
        self.assertEqual(next(r['on_hand'] for r in p['rows'] if r['sku']=='84077'),0)
    def test_inactivity_flag_uses_only_the_eight_prior_weeks(self):
        rows=inputs(app.DATA['items'],app.LOCK,app.ORIGIN,'selected',DEFAULT)
        for r in rows:
            item=next(i for i in app.DATA['items'] if i['sku']==r['sku'])
            self.assertEqual(r['inactive_review'],sum(item['weekly'][app.ORIGIN-8:app.ORIGIN])==0)
        self.assertTrue(next(r['inactive_review'] for r in rows if r['sku']=='16033'))
    def test_pipeline_reduces_order_request(self):
        r=self.row();r['on_order']=100
        p=allocate([r],{**DEFAULT,'buffer':0})
        self.assertEqual(p['rows'][0]['desired'],0)
    def test_invalid_assumptions_not_silently_clamped(self):
        for key,value in [('lead',4),('lead',.5),('pack',0),('budget',-1),('budget',math.nan),('budget',1.001),('stock_weeks',9),('buffer',2)]:
            with self.subTest(key=key,value=value):
                with self.assertRaises(ValueError):app.calculate({'assumptions':{**DEFAULT,key:value}})
        with self.assertRaises(ValueError):app.calculate({'stock_overrides':{'unknown':1}})
        with self.assertRaises(ValueError):app.calculate({'stock_overrides':{'84077':True}})
        with self.assertRaises(ValueError):app.calculate({'method':'magic'})
    def test_order_arrival_timing_and_inventory_balance(self):
        item={'sku':'A','name':'A','segment':'frequent','weekly':[10]*65,'training_median_sell_price':2}
        lock={'selected':{'A':'mean8'},'bands':{m:{'A':[0]*4} for m in ('selected','seasonal52')}}
        a={**DEFAULT,'lead':1,'stock_weeks':0,'pack':1,'buffer':0,'budget':1000}
        s=simulate([item],lock,60,63,'selected',a)
        self.assertEqual([w['arrivals'] for w in s['weeks']],[0,0,20])
        self.assertEqual([w['served'] for w in s['weeks']],[0,0,10])
        self.assertEqual(s['totals']['ending_stock'],10)
    def test_identical_start_and_budget_across_policies(self):
        for a in (DEFAULT,{**DEFAULT,'budget':0,'lead':3},{**DEFAULT,'budget':15000,'lead':0}):
            sims=[simulate(app.DATA['items'],app.LOCK,app.ORIGIN,app.ORIGIN+8,m,a) for m in ('selected','seasonal52')]
            self.assertEqual(sims[0]['totals']['initial_units'],sims[1]['totals']['initial_units'])
            self.assertEqual(sims[0]['totals']['observed_units'],sims[1]['totals']['observed_units'])
            for s in sims:
                t=s['totals']
                self.assertTrue(all(w['spend_cents']<=round(a['budget']*100) for w in s['weeks']))
                self.assertEqual(t['initial_units']+t['received_units']-t['served_units'],t['ending_stock'])
                self.assertEqual(t['served_units']+t['unmet_units'],98173)
    def test_budget_and_lead_change_actual_calculations(self):
        base=app.calculate({})
        more=app.calculate({'assumptions':{**DEFAULT,'budget':15000}})
        slower=app.calculate({'assumptions':{**DEFAULT,'lead':3}})
        self.assertNotEqual(base['plan']['spend_cents'],more['plan']['spend_cents'])
        self.assertNotEqual(base['comparison']['selected']['totals']['fill_rate'],more['comparison']['selected']['totals']['fill_rate'])
        self.assertNotEqual(base['comparison']['selected']['totals']['fill_rate'],slower['comparison']['selected']['totals']['fill_rate'])
    def test_simulation_first_decision_does_not_use_later_actuals(self):
        changed=deepcopy(app.DATA['items'])
        for i in changed:i['weekly'][app.ORIGIN+1:]=[99999]*7
        first=simulate(app.DATA['items'],app.LOCK,app.ORIGIN,app.ORIGIN+8,'selected',DEFAULT)['weeks'][0]
        altered=simulate(changed,app.LOCK,app.ORIGIN,app.ORIGIN+8,'selected',DEFAULT)['weeks'][0]
        self.assertEqual(first,altered)

class HTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
        cls.thread=Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
    @classmethod
    def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.thread.join()
    def request(self,method,path,body=None,headers=None):
        c=HTTPConnection('127.0.0.1',self.server.server_port)
        c.request(method,path,body=body,headers=headers or {})
        r=c.getresponse();code=r.status;data=r.read();c.close();return code,data
    def test_http_state_plan_and_results(self):
        code,data=self.request('GET','/api/state');self.assertEqual(code,200)
        self.assertEqual(json.loads(data)['report']['observations'],192)
        code,data=self.request('POST','/api/plan',json.dumps({'assumptions':{**DEFAULT,'budget':0}}),{'Content-Type':'application/json'})
        self.assertEqual(code,200);self.assertEqual(json.loads(data)['plan']['spend_cents'],0)
    def test_http_origin_body_and_route_boundaries(self):
        for method,path,body,h,expected in [
            ('GET','/api/state',None,{'Origin':'https://example.com'},403),
            ('GET','/api/state',None,{'Host':'evil.example'},403),
            ('GET','/../data/online_retail_II.xlsx',None,{},404),
            ('POST','/api/plan','{}',{'Content-Type':'text/plain'},415),
            ('POST','/api/plan','not json',{'Content-Type':'application/json'},400),
            ('POST','/api/plan','{"budget":3}',{'Content-Type':'application/json'},400),
            ('POST','/api/plan','x'*9000,{'Content-Type':'application/json'},413)]:
            with self.subTest(path=path,h=h):self.assertEqual(self.request(method,path,body,h)[0],expected)

if __name__=='__main__':unittest.main()
