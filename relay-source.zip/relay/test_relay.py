"""Contract and recovery tests; all traffic stays on loopback."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import re
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request

from app import ROOT, Store, encode, make_server, signature


def request(origin, path, payload=None, headers=None):
    data = payload if isinstance(payload, bytes) else encode(payload) if payload is not None else None
    req = urllib.request.Request(origin+path, data=data, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=5) as response:
            body = response.read()
            return response.status, json.loads(body) if response.headers.get_content_type() == "application/json" else body.decode()
    except urllib.error.HTTPError as exc:
        return exc.code, json.load(exc)


def wait_for(read, predicate, timeout=8):
    deadline = time.monotonic()+timeout
    while time.monotonic() < deadline:
        result = read()
        if predicate(result):
            return result
        time.sleep(.02)
    raise AssertionError("Expected state did not arrive")


class RelayTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.server, self.app = make_server(self.temp.name, lease_seconds=.25, retry_base=.04)
        self.serving = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.serving.start()
        self.app.start()

    def tearDown(self):
        self.app.close()
        self.server.shutdown()
        self.server.server_close()
        self.temp.cleanup()

    def send(self, payload, signed=None):
        body = encode(payload)
        return request(self.app.origin, "/api/webhook", body,
                       {"X-Relay-Signature": signed or signature(body, self.app.secret)})

    def lead(self, **updates):
        return {"event_id": "evt-test", "tenant": "test", "name": "Test Lead", "email": "lead@example.invalid", **updates}

    def final(self, event_id):
        return wait_for(lambda: next(e for e in self.app.snapshot()["events"] if e["id"] == event_id),
                        lambda e: e["status"] in ("delivered", "review", "failed"))

    def calls(self):
        with self.app.crm.store.connection() as db:
            return sum(row[0] for row in db.execute("SELECT count FROM calls"))

    def test_signed_delivery(self):
        code, result = self.send(self.lead())
        self.assertEqual(code, 202)
        event = self.final(result["id"])
        self.assertEqual((event["status"], event["attempts"], self.calls()), ("delivered", 1, 1))

    def test_concurrent_duplicates(self):
        with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
            results = list(pool.map(lambda _: self.send(self.lead()), range(100)))
        self.assertEqual(sum(code == 202 for code, _ in results), 1)
        self.assertEqual(sum(code == 200 for code, _ in results), 99)
        self.final(results[0][1]["id"])
        state = self.app.snapshot()
        self.assertEqual((state["metrics"]["unique"], state["metrics"]["duplicates"], self.calls()), (1, 99, 1))
        self.assertEqual(len(state["contacts"]), 1)

    def test_conflicting_key_rejected(self):
        _, result = self.send(self.lead())
        self.assertEqual(self.send(self.lead(name="Changed content"))[0], 409)
        self.assertEqual(self.final(result["id"])["contact"]["name"], "Test Lead")

    def test_tenants_are_isolated(self):
        for tenant in ("alpha", "beta"):
            _, result = self.send(self.lead(tenant=tenant))
            self.final(result["id"])
        self.assertEqual(len(self.app.snapshot()["contacts"]), 2)

    def test_upsert_existing_contact(self):
        for event_id, name in (("evt-a", "First"), ("evt-b", "Updated")):
            _, result = self.send(self.lead(event_id=event_id, name=name))
            self.final(result["id"])
        self.assertEqual(len(self.app.snapshot()["contacts"]), 1)
        self.assertEqual(self.app.snapshot()["contacts"][0]["name"], "Updated")

    def test_outage_retries_safely(self):
        result = self.app.demo("outage")
        event = self.final(result["event_id"])
        self.assertEqual((event["status"], event["attempts"], self.calls()), ("delivered", 3, 3))
        self.assertEqual(len(self.app.snapshot()["contacts"]), 1)

    def test_lost_response_reconciles_without_resend(self):
        result = self.app.demo("lost_response")
        event = self.final(result["event_id"])
        self.assertEqual((event["status"], event["attempts"], self.calls()), ("delivered", 2, 1))
        self.assertIn("reconciled", [item["kind"] for item in self.app.snapshot()["audit"]])

    def test_unknown_unsafe_outcome_held(self):
        result = self.app.demo("unsafe")
        self.assertEqual(self.final(result["event_id"])["status"], "review")
        self.assertEqual(self.calls(), 1)
        self.assertEqual(len(self.app.snapshot()["alerts"]), 1)

    def test_permanent_error_not_retried(self):
        result = self.app.demo("rejected")
        self.assertEqual(self.final(result["event_id"])["status"], "failed")
        self.assertEqual(self.calls(), 1)
        self.assertEqual(len(self.app.snapshot()["contacts"]), 0)

    def test_retry_budget_bounded(self):
        def unavailable(*args, **kwargs):
            raise urllib.error.URLError("test unavailable")
        self.app.request_crm = unavailable
        result = self.app.demo("normal")
        event = self.final(result["event_id"])
        self.assertEqual((event["status"], event["attempts"]), ("review", 4))

    def test_invalid_requests(self):
        payload = self.lead()
        for bad in ("wrong", signature(encode(payload), self.app.secret, int(time.time())-600)):
            self.assertEqual(self.send(payload, bad)[0], 401)
        for payload in (self.lead(mode=[]), self.lead(email="invalid"), self.lead(tenant=""), self.lead(extra="invalid")):
            self.assertEqual(self.send(payload)[0], 400)
        self.assertEqual(request(self.app.origin, "/api/demo", {"mode": []}, {"X-Relay-Control": self.app.control})[0], 400)
        self.assertEqual(request(self.app.origin, "/api/demo", {"mode": "normal"})[0], 403)
        self.assertEqual(request(self.app.origin, "/api/state", headers={"Origin": "https://evil.example"})[0], 403)
        self.assertEqual(request(self.app.origin, "/api/state", headers={"Host": "evil.example"})[0], 403)
        self.assertEqual(request(self.app.origin, "/api/webhook", b"x"*32769)[0], 413)
        body = b"{invalid"
        self.assertEqual(request(self.app.origin, "/api/webhook", body, {"X-Relay-Signature": signature(body, self.app.secret)})[0], 400)


class LeaseTests(unittest.TestCase):
    def test_stale_worker_cannot_complete_new_lease(self):
        with tempfile.TemporaryDirectory() as directory:
            store = Store(Path(directory)/"events.sqlite3")
            store.ingest({"event_id": "fence", "tenant": "test", "name": "Test", "email": "test@example.invalid"})
            old = store.claim(.01)
            time.sleep(.02)
            new = store.claim(2)
            store.finish(old, "delivered", "Stale result", "WRONG")
            self.assertEqual(store.snapshot()["events"][0]["status"], "processing")
            store.finish(new, "delivered", "Current result", "RIGHT")
            self.assertEqual(store.snapshot()["events"][0]["remote_id"], "RIGHT")

    def test_expired_unsafe_lease_held_not_resent(self):
        with tempfile.TemporaryDirectory() as directory:
            store = Store(Path(directory)/"events.sqlite3")
            store.ingest({"event_id": "opaque", "tenant": "test", "name": "Test", "email": "test@example.invalid", "mode": "unsafe"})
            store.claim(.01)
            time.sleep(.02)
            self.assertIsNone(store.claim(2))
            self.assertEqual(store.snapshot()["events"][0]["status"], "review")
            self.assertEqual(len(store.snapshot()["alerts"]), 1)


class CrashTests(unittest.TestCase):
    def test_real_process_crash_after_crm_commit(self):
        with tempfile.TemporaryDirectory() as directory:
            with socket.socket() as sock:
                sock.bind(("127.0.0.1", 0))
                port = sock.getsockname()[1]
            origin = f"http://127.0.0.1:{port}"
            args = [sys.executable, str(ROOT/"app.py"), "--port", str(port), "--data-dir", directory, "--lease-seconds", ".25"]
            processes = []
            def launch():
                processes.append(subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
                def health():
                    try:
                        return request(origin, "/api/health")[0] == 200
                    except OSError:
                        return False
                wait_for(health, bool)
            try:
                launch()
                html = request(origin, "/")[1]
                token = re.search(r'name="relay-control" content="([^"]+)"', html)[1]
                code, result = request(origin, "/api/demo", {"mode": "worker_stop"}, {"X-Relay-Control": token})
                self.assertEqual(code, 202)
                state = wait_for(lambda: request(origin, "/api/state")[1], lambda s: s["worker_paused"])
                self.assertEqual((state["events"][0]["status"], len(state["contacts"])), ("processing", 1))
                processes[-1].kill()
                processes[-1].wait(timeout=3)
                launch()
                state = wait_for(lambda: request(origin, "/api/state")[1], lambda s: s["events"][0]["status"] == "delivered")
                self.assertEqual((len(state["contacts"]), state["events"][0]["attempts"]), (1, 2))
                import sqlite3
                with sqlite3.connect(Path(directory)/"crm.sqlite3") as db:
                    self.assertEqual(db.execute("SELECT SUM(count) FROM calls").fetchone()[0], 1)
            finally:
                for process in processes:
                    if process.poll() is None:
                        process.kill()
                    process.wait(timeout=3)


if __name__ == "__main__":
    unittest.main(verbosity=2)
