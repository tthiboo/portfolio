"""One-page portfolio case from recorded verification and the actual local UI."""
import json
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader

ROOT = Path(__file__).resolve().parent


def build():
    report = json.loads((ROOT / 'portfolio/verification.json').read_text())
    assert report['tests_failed'] == 0
    results = report['results']
    out = ROOT / 'output/pdf/relay-case.pdf'
    out.parent.mkdir(parents=True, exist_ok=True)
    c = canvas.Canvas(str(out), pagesize=A4)
    c.setTitle('Relay - Webhook recovery and CRM delivery')
    c.setAuthor('Mark Newton')
    width, height = A4
    bg, ink, muted, green, line = map(HexColor, ['#0d1117', '#d7e2ec', '#8a9aab', '#89e2bb', '#293441'])
    c.setFillColor(bg)
    c.rect(0, 0, width, height, fill=1, stroke=0)
    c.setFillColor(muted)
    c.setFont('Courier', 8)
    c.drawString(40, 800, 'MARK NEWTON / INDEPENDENT ENGINEERING / LOCAL SYSTEM')
    c.setFillColor(ink)
    c.setFont('Helvetica-Bold', 48)
    c.drawString(40, 738, 'Relay')
    c.setFillColor(green)
    c.setFont('Courier-Bold', 31)
    c.drawRightString(555, 756, str(report['tests_passed']))
    c.setFillColor(muted)
    c.setFont('Courier', 7)
    c.drawRightString(555, 740, 'AUTOMATED CHECKS PASSED')
    c.setFillColor(ink)
    c.setFont('Helvetica', 13)
    c.drawString(40, 710, 'Webhook recovery and CRM delivery.')
    c.setFillColor(muted)
    c.setFont('Helvetica', 9)
    c.drawString(40, 690, 'Persist first. Reconcile uncertain outcomes. Retry only when safe.')
    c.setStrokeColor(line)
    c.line(40, 671, 555, 671)
    c.drawImage(ImageReader(str(ROOT / 'portfolio/relay-cover.jpg')), 40, 363,
                width=515, height=289.6875, preserveAspectRatio=True, mask='auto')
    c.setFillColor(muted)
    c.setFont('Courier', 7)
    c.drawString(40, 345, 'ACTUAL LOCAL DEMO / PERSISTED EVENT COUNTS / SEPARATE CRM DATABASE')
    c.setFillColor(green)
    c.setFont('Courier', 8)
    c.drawString(40, 318, 'RECORDED ACCEPTANCE EVIDENCE')
    c.setFillColor(muted)
    c.setFont('Courier', 7)
    for x, label in [(40, 'FAILURE PATH'), (216, 'MEASURED RESULT'), (502, 'CRM POSTS')]:
        c.drawString(x, 295, label)
    copies = results['concurrent_duplicate_submissions']
    rows = [
        ('Concurrent copies', f"{copies['http_submissions']} submissions / {copies['unique_events']} event / {copies['duplicates_blocked']} repeats blocked", str(copies['crm_post_calls'])),
        ('Lost response', 'Existing receipt recovered; no resend', str(results['lost_response']['crm_post_calls'])),
        ('Forced process crash', 'Restart recovered the committed receipt', str(results['forced_process_crash_after_crm_commit']['crm_post_calls'])),
        ('Unknown opaque outcome', 'Held for review; no automatic resend', str(results['unknown_opaque_outcome']['crm_post_calls'])),
    ]
    for i, (failure, result, calls) in enumerate(rows):
        y = 271 - 29 * i
        c.setStrokeColor(line)
        c.line(40, y + 15, 555, y + 15)
        c.setFillColor(ink)
        c.setFont('Helvetica', 8.5)
        c.drawString(40, y, failure)
        c.setFillColor(muted)
        c.setFont('Helvetica', 8)
        c.drawString(216, y, result)
        c.setFillColor(green)
        c.setFont('Courier-Bold', 10)
        c.drawRightString(546, y, calls)
    c.setStrokeColor(line)
    c.line(40, 167, 555, 167)
    c.setFillColor(muted)
    c.setFont('Helvetica', 8)
    c.drawString(40, 146, 'Signed requests, concurrent deduplication, bounded retries, owner fencing and audit traces.')
    c.drawString(40, 130, 'Functional checks on a controlled local simulator. No production reliability or scale claim.')
    c.setFillColor(ink)
    c.setFont('Helvetica-Bold', 9)
    c.drawString(40, 97, 'Python / SQLite / HTTP APIs / JavaScript')
    c.setFillColor(muted)
    c.setFont('Helvetica', 8)
    c.drawString(40, 77, 'Fictional leads. Independent demonstration. Source, tests and recorded evidence included.')
    c.drawString(40, 61, 'No paid client work or customer deployment is claimed. The n8n template was not executed.')
    c.save()
    print(out)


if __name__ == '__main__':
    build()
