# Relay

**Every event. Accounted for.** Independent engineering project by Mark Newton.

A working webhook reliability console. Signed incoming leads are saved before processing, concurrent repeats are blocked, and a separate CRM database records the outcome over real loopback HTTP.

## Run

Python 3.11 or newer; no packages, API keys, subscriptions or external accounts.

```sh
python3 app.py --port 8767
```

Open http://127.0.0.1:8767. Data survives a restart in `data/`. The included `Launch Relay.command` starts the same local app on macOS.

```sh
python3 -m unittest -v test_relay
```

Tests use temporary databases and loopback ports; they do not modify the demonstration database. The crash test forcefully terminates **its own child process** after a CRM commit, then starts a new process against the same databases.

## What to try

| Scenario | Expected result |
|---|---|
| Clean delivery | One event, one confirmed CRM contact |
| Duplicate burst | 12 concurrent submissions, one event, 11 repeats blocked |
| CRM unavailable | Two HTTP 503 responses before commit, success on attempt three |
| Lost confirmation | CRM commits and closes its socket; Relay retrieves the receipt without another POST |
| Worker interruption | Pause after CRM commit; click Resume worker to recover the expired lease |
| No safe retry | Unknown result with no idempotency/lookup contract: hold for human review |
| Permanent rejection | HTTP 422: stop after one attempt and create an attention record |

The worker interruption button **simulates** an interruption. The automated test separately verifies an actual process crash/restart.

## Architecture

```mermaid
flowchart LR
    A[Signed webhook] --> B[Validate signature and payload]
    B --> C[(Relay SQLite inbox + audit)]
    C --> D[Two workers / fenced leases]
    D --> E[CRM HTTP adapter]
    E --> F[(Separate CRM SQLite state)]
    D --> G[Receipt reconciliation]
    G --> F
    C --> H[Read-only state API / dashboard]
```

- Atomic `UNIQUE(tenant,event_key)` and a canonical payload digest distinguish repeats from conflicting submissions. Conflicts return 409.
- HMAC-SHA256 signs timestamp + raw body, with a five-minute acceptance window. The committed inbox prevents repeated processing of valid replays.
- Leases let another worker recover abandoned work. Owner tokens prevent a stale worker from completing a replacement worker's lease.
- The CRM simulator accepts operation keys and retains durable receipts. On later attempts Relay checks the receipt first; it never assumes an absent HTTP response means the operation failed.
- If the adapter cannot support safe retries, both an unknown transport outcome and an expired lease move the event to review.
- Normal transport retries use exponential delay and stop at four claimed attempts. Permanent errors stop immediately. Attention records are stored locally; this demo sends no email or Slack alerts.
- Contacts use tenant/email upsert. This is a demonstration CRM contract, not a universal guarantee about third-party APIs.

## HTTP contract

`POST /api/webhook` accepts `event_id`, `tenant`, `name`, `email`, and optional demo `mode`. `X-Relay-Signature` must match the raw JSON bytes. New events return 202; matching repeats return 200; key/content conflicts return 409.

`GET /api/state` feeds the dashboard. Control routes `/api/demo`, `/api/worker`, and `/mock-crm/*` require a random per-process control token. The token is embedded in the local page for the demo controls; it is not a production authentication mechanism.

The optional `integrations/n8n-demo.json` is an **unexecuted import template** for calling the scenario endpoint. It is not required to run Relay. Configure a base URL reachable from your n8n instance and the current local control token before executing. Do not expose the app publicly to connect it.

## Scope and limits

This is a local demonstration with fictional leads. It is not commissioned client work, a production deployment, or a paid outcome. Both services run in one Python process, use different databases, and communicate over HTTP. The CRM deliberately injects failures; no real CRM is connected.

SQLite makes this demo runnable with no installation or hosting spend. Python's development HTTP server, demo controls and locally readable control token are unsuitable for public deployment. Production work needs a real CRM adapter/contract, proper user authentication, managed deployment, operational monitoring, retention/PII controls, queue/lease sizing, indexes and load testing for the target workload. SQLite is not presented as a benchmark for distributed scale.

The dashboard displays the latest 200 events and 120 audit entries; metric counts cover the full local inbox. CRM records include committed contacts even when Relay cannot confirm an opaque operation. The recovery metric counts **actions**, not unique recovered events.

## Portfolio evidence

- `portfolio/case.md`: ready-to-use project description and client-facing explanation.
- `portfolio/verification.json`: recorded test results with timestamps and interpreter details.
- `portfolio/*.jpg`: actual screenshots of the working demo.
- `portfolio/relay-walkthrough.mp4`: short walkthrough assembled from captured UI states (when present).
- `output/pdf/relay-case.pdf`: one-page portfolio case with an actual interface capture and recorded acceptance evidence.
- `portfolio/relay-source.zip`: source and evidence bundle (when present).

The design and implementation are original to this independent project. The market reference is an automation qualification brief about CRM API work: [Upwork reference](https://www.upwork.com/freelance-jobs/apply/Automation-Specialist-for-Paid-Qualification-Project-n8n-Make-CRM-API-Integrations_~022101749575310645866/). The [n8n duplicate orders discussion](https://community.n8n.io/t/duplicate-orders/312811?tl=en) illustrates the underlying reliability problem. Neither is claimed as a client or endorsement.

## Sources for technical choices

[SQLite transactions](https://www.sqlite.org/lang_transaction.html), [Python HTTP server limitations](https://docs.python.org/3/library/http.server.html), [n8n HTTP Request node](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.httprequest/).


## Interface

The interface uses a live delivery topology with counters read from persisted state, a compact scenario console and event traces.
