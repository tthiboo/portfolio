# Relay — Webhook Recovery & CRM Automation

**Independent engineering project · Mark Newton**

## Copy for the project field

Repeated webhooks. CRM outages. A delivery that succeeds, then loses its response.

I built Relay to handle those failure paths: a durable event inbox, concurrent deduplication, signed requests, bounded retries, receipt reconciliation, and an operations dashboard.

Verified locally: 100 concurrent copies produced one event and one CRM call. After a forced process crash following CRM commit, a new process recovered the receipt without resending. When safe recovery cannot be established, the event stops for review.

Python, SQLite, HTTP APIs, JavaScript. Working local demo, automated tests and source included. Fictional data; independent project.

## What the demo proves

| Failure | Evidence |
|---|---|
| Concurrent repeats | 100 HTTP submissions → one saved event, 99 repeats blocked, one CRM POST |
| Commit with lost response | Receipt recovered on attempt two; one CRM POST |
| Crash after CRM commit | Process forcibly terminated and restarted against persisted state; one CRM POST |
| Temporary outage | Two injected 503 responses; third attempt accepted |
| Opaque API outcome | Event held; no automatic resend |
| Worker lease with opaque outcome | Expired processing lease held for review |
| Stale worker | Old lease owner cannot overwrite the current owner's result |
| Permanent API rejection | One attempt; failure reason and attention record retained |

Fourteen automated tests passed. See `verification.json` for the recorded run. These are functional results on a controlled local simulator, not real-customer reliability percentages or throughput promises.

## Positioning

Useful for lead routing, order intake, form-to-CRM flows and systems receiving repeated webhooks. The paid deliverable for a real buyer would be an adapter to their API plus the same failure-path checks against its documented contract.

Start with one bounded flow: one incoming source, one destination, agreed acceptance tests. Extend after the first paid milestone. Infrastructure/API fees belong in the agreed scope.

## Demo route

1. Duplicate burst: show 12 submissions becoming one event and 11 blocked repeats.
2. Lost confirmation: open the trace; show the missing response followed by an existing receipt.
3. Worker interruption: show pending state, resume, then recovered receipt.
4. No safe retry: show the explicit review state instead of a speculative resend.

## Claims to keep exact

Independent project. Local HTTP CRM simulator. SQLite. Two workers. Fourteen functional tests. No commercial client, production deployment, paid delivery, distributed-scale benchmark or n8n execution is claimed.

## Короткое описание на русском

Relay — обработка вебхуков и восстановление доставки в CRM. Сохранение событий до обработки, защита от одновременных дублей, проверка подписи, ограниченные повторы и журнал действий. Если CRM приняла заявку, но ответ потерялся, система находит сохраненное подтверждение. Если безопасный повтор невозможен — останавливает событие для проверки.

В локальных тестах: 100 копий заявки → одно событие и один вызов CRM. Проверен аварийный перезапуск после записи в CRM. Самостоятельный проект на демонстрационных данных.


## Interface

The interface uses a live delivery topology with counters read from persisted state, a compact scenario console and event traces.
