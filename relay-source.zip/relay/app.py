"""Relay: local, dependency-free webhook reliability demonstration."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
import hashlib
import hmac
from http.client import RemoteDisconnected
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

ROOT = Path(__file__).resolve().parent
MODES = {"normal", "duplicates", "outage", "lost_response", "worker_stop", "unsafe", "rejected"}


class Problem(Exception):
    def __init__(self, status, message):
        self.status, self.message = status, message
        super().__init__(message)


def encode(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode()


def signature(body, secret, timestamp=None):
    timestamp = int(time.time()) if timestamp is None else timestamp
    digest = hmac.new(secret.encode(), str(timestamp).encode() + b"." + body, hashlib.sha256).hexdigest()
    return f"t={timestamp},v1={digest}"


def validate_signature(body, header, secret):
    try:
        fields = dict(part.split("=", 1) for part in header.split(","))
        timestamp = int(fields["t"])
        expected = signature(body, secret, timestamp).split("v1=", 1)[1]
        valid = abs(time.time() - timestamp) <= 300 and hmac.compare_digest(expected, fields["v1"])
    except (ValueError, KeyError, TypeError):
        valid = False
    if not valid:
        raise Problem(401, "Invalid or expired webhook signature")


def validate_payload(payload):
    if not isinstance(payload, dict):
        raise Problem(400, "Expected a JSON object")
    for key in ("event_id", "tenant", "name", "email"):
        if not isinstance(payload.get(key), str) or not payload[key].strip() or len(payload[key]) > 200:
            raise Problem(400, f"Invalid {key}")
    if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", payload["email"]):
        raise Problem(400, "Invalid email")
    if not isinstance(payload.get("mode", "normal"), str) or payload.get("mode", "normal") not in MODES:
        raise Problem(400, "Unknown delivery scenario")
    if set(payload) - {"event_id", "tenant", "name", "email", "mode"}:
        raise Problem(400, "Unexpected payload fields")


class Store:
    def __init__(self, path):
        self.path = str(path)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY, tenant TEXT NOT NULL, event_key TEXT NOT NULL,
                    payload TEXT NOT NULL, digest TEXT NOT NULL, mode TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'queued', attempts INTEGER NOT NULL DEFAULT 0,
                    next_at REAL NOT NULL, lease_until REAL, owner TEXT, created_at REAL NOT NULL,
                    updated_at REAL NOT NULL, remote_id TEXT, last_error TEXT,
                    UNIQUE(tenant, event_key)
                );
                CREATE INDEX IF NOT EXISTS due_events ON events(status, next_at);
                CREATE TABLE IF NOT EXISTS audit (
                    id INTEGER PRIMARY KEY, event_id INTEGER, kind TEXT NOT NULL,
                    message TEXT NOT NULL, at REAL NOT NULL,
                    FOREIGN KEY(event_id) REFERENCES events(id)
                );
                CREATE TABLE IF NOT EXISTS alerts (
                    id INTEGER PRIMARY KEY, event_id INTEGER NOT NULL UNIQUE,
                    message TEXT NOT NULL, at REAL NOT NULL,
                    FOREIGN KEY(event_id) REFERENCES events(id)
                );
            """)

    @contextmanager
    def connection(self):
        db = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA busy_timeout=10000")
        try:
            yield db
        finally:
            db.close()

    @contextmanager
    def transaction(self):
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                yield db
                db.execute("COMMIT")
            except BaseException:
                db.execute("ROLLBACK")
                raise

    @staticmethod
    def log(db, event_id, kind, message):
        db.execute("INSERT INTO audit(event_id,kind,message,at) VALUES(?,?,?,?)",
                   (event_id, kind, message, time.time()))

    def ingest(self, payload):
        normalized = {**payload, "mode": payload.get("mode", "normal")}
        text = json.dumps(normalized, sort_keys=True, separators=(",", ":"))
        digest = hashlib.sha256(text.encode()).hexdigest()
        now = time.time()
        with self.transaction() as db:
            row = db.execute("SELECT * FROM events WHERE tenant=? AND event_key=?",
                             (payload["tenant"], payload["event_id"])).fetchone()
            if row:
                if row["digest"] != digest:
                    self.log(db, row["id"], "conflict", "Same event key with different content rejected")
                    result = {"conflict": True}
                else:
                    self.log(db, row["id"], "duplicate", "Repeated delivery blocked before CRM")
                    result = {"id": row["id"], "duplicate": True, "status": row["status"]}
            else:
                cursor = db.execute("""INSERT INTO events
                    (tenant,event_key,payload,digest,mode,next_at,created_at,updated_at)
                    VALUES(?,?,?,?,?,?,?,?)""", (payload["tenant"], payload["event_id"], text,
                    digest, normalized["mode"], now, now, now))
                self.log(db, cursor.lastrowid, "received", "Signature checked; event saved durably")
                result = {"id": cursor.lastrowid, "duplicate": False, "status": "queued"}
        if result.get("conflict"):
            raise Problem(409, "Event key already belongs to a different payload")
        return result

    def claim(self, lease_seconds):
        now = time.time()
        with self.transaction() as db:
            expired = db.execute("SELECT id,mode FROM events WHERE status='processing' AND lease_until<?", (now,)).fetchall()
            for row in expired:
                if row["mode"] == "unsafe":
                    message = "Worker lease expired without a safe retry contract; inspect CRM before retry"
                    db.execute("UPDATE events SET status='review',owner=NULL,lease_until=NULL,last_error=?,updated_at=? WHERE id=?", (message, now, row["id"]))
                    self.log(db, row["id"], "review", message)
                    db.execute("INSERT OR IGNORE INTO alerts(event_id,message,at) VALUES(?,?,?)", (row["id"], message, now))
                    continue
                self.log(db, row["id"], "recovered", "Expired worker lease recovered; checking CRM before retry")
                db.execute("UPDATE events SET status='retrying',owner=NULL,lease_until=NULL,next_at=?,updated_at=? WHERE id=?",
                           (now, now, row["id"]))
            row = db.execute("""SELECT * FROM events WHERE status IN ('queued','retrying')
                              AND next_at<=? ORDER BY next_at,id LIMIT 1""", (now,)).fetchone()
            if not row:
                return None
            owner = uuid.uuid4().hex
            db.execute("""UPDATE events SET status='processing',attempts=attempts+1,
                       owner=?,lease_until=?,updated_at=? WHERE id=?""", (owner, now+lease_seconds, now, row["id"]))
            self.log(db, row["id"], "processing", f"Delivery attempt {row['attempts']+1} claimed")
            return dict(db.execute("SELECT * FROM events WHERE id=?", (row["id"],)).fetchone())

    def annotate(self, event, kind, message):
        with self.transaction() as db:
            row = db.execute("SELECT owner FROM events WHERE id=?", (event["id"],)).fetchone()
            if row and row["owner"] == event["owner"]:
                self.log(db, event["id"], kind, message)

    def finish(self, event, status, message, remote_id=None, delay=0):
        now = time.time()
        with self.transaction() as db:
            cursor = db.execute("""UPDATE events SET status=?,remote_id=?,last_error=?,next_at=?,
                    updated_at=?,lease_until=NULL,owner=NULL WHERE id=? AND owner=? AND status='processing'""",
                    (status, remote_id, None if status == "delivered" else message, now+delay,
                     now, event["id"], event["owner"]))
            if cursor.rowcount:
                self.log(db, event["id"], status, message)
                if status in ("review", "failed"):
                    db.execute("INSERT OR IGNORE INTO alerts(event_id,message,at) VALUES(?,?,?)",
                               (event["id"], message, now))

    def snapshot(self):
        with self.connection() as db:
            # One read transaction gives a consistent event/audit/metrics snapshot.
            db.execute("BEGIN")
            events = [dict(r) for r in db.execute("SELECT * FROM events ORDER BY id DESC LIMIT 200")]
            for event in events:
                event["contact"] = json.loads(event.pop("payload"))
                event.pop("digest")
                event.pop("owner")
            counts = dict(db.execute("SELECT status,COUNT(*) FROM events GROUP BY status").fetchall())
            kinds = dict(db.execute("SELECT kind,COUNT(*) FROM audit GROUP BY kind").fetchall())
            return {"events": events, "audit": [dict(r) for r in db.execute("SELECT * FROM audit ORDER BY id DESC LIMIT 120")],
                    "alerts": [dict(r) for r in db.execute("SELECT * FROM alerts ORDER BY id DESC LIMIT 100")],
                    "metrics": {"unique": sum(counts.values()), "delivered": counts.get("delivered", 0),
                                "duplicates": kinds.get("duplicate", 0),
                                "review": counts.get("review", 0)+counts.get("failed", 0),
                                "recovered": kinds.get("recovered", 0)+kinds.get("reconciled", 0),
                                "pending": sum(counts.get(s, 0) for s in ("queued", "retrying", "processing"))}}


class CRM:
    """Separate durable state, accessed by the worker over real loopback HTTP."""
    def __init__(self, path):
        self.store = Store(path)
        with self.store.connection() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS contacts (
                    id TEXT PRIMARY KEY, tenant TEXT NOT NULL, email TEXT NOT NULL,
                    name TEXT NOT NULL, created_at REAL NOT NULL, UNIQUE(tenant,email)
                );
                CREATE TABLE IF NOT EXISTS operations (
                    operation_key TEXT PRIMARY KEY, contact_id TEXT NOT NULL,
                    digest TEXT NOT NULL, at REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS calls(operation_key TEXT PRIMARY KEY, count INTEGER NOT NULL);
            """)

    def upsert(self, payload, key, mode):
        digest = hashlib.sha256(encode(payload)).hexdigest()
        with self.store.transaction() as db:
            db.execute("INSERT INTO calls VALUES(?,1) ON CONFLICT(operation_key) DO UPDATE SET count=count+1", (key,))
            attempt = db.execute("SELECT count FROM calls WHERE operation_key=?", (key,)).fetchone()[0]
            existing = db.execute("SELECT * FROM operations WHERE operation_key=?", (key,)).fetchone()
            if existing and mode != "unsafe":
                if existing["digest"] != digest:
                    return 409, {"error": "Idempotency key reused with different contact"}, False
                return 200, {"id": existing["contact_id"], "reused": True}, False
            if mode == "outage" and attempt <= 2:
                return 503, {"error": "CRM unavailable before commit"}, False
            if mode == "rejected":
                return 422, {"error": "CRM rejected this demonstration contact"}, False
            contact = db.execute("SELECT id FROM contacts WHERE tenant=? AND email=?",
                                 (payload["tenant"], payload["email"])).fetchone()
            contact_id = contact["id"] if contact else "CRM-" + uuid.uuid4().hex[:8].upper()
            if contact:
                db.execute("UPDATE contacts SET name=? WHERE id=?", (payload["name"], contact_id))
            else:
                db.execute("INSERT INTO contacts VALUES(?,?,?,?,?)", (contact_id, payload["tenant"],
                           payload["email"], payload["name"], time.time()))
            if mode != "unsafe":
                db.execute("INSERT INTO operations VALUES(?,?,?,?)", (key, contact_id, digest, time.time()))
            return 201, {"id": contact_id, "reused": False}, mode in ("lost_response", "unsafe") and attempt == 1

    def lookup(self, key):
        with self.store.connection() as db:
            row = db.execute("SELECT contact_id FROM operations WHERE operation_key=?", (key,)).fetchone()
            return {"id": row[0]} if row else None

    def contacts(self):
        with self.store.connection() as db:
            return [dict(r) for r in db.execute("SELECT * FROM contacts ORDER BY created_at DESC LIMIT 200")]


class Application:
    def __init__(self, data_dir, secret="relay-local-demo-secret", lease_seconds=2, retry_base=.4):
        self.store = Store(Path(data_dir)/"relay.sqlite3")
        self.crm = CRM(Path(data_dir)/"crm.sqlite3")
        self.secret, self.control = secret, secrets.token_urlsafe(32)
        self.lease_seconds, self.retry_base = lease_seconds, retry_base
        self.origin = None
        self.stop = threading.Event()
        self.paused = threading.Event()
        self.wake = threading.Event()
        self.demo_lock = threading.Lock()
        self.threads = []

    def ingest(self, body, header):
        validate_signature(body, header, self.secret)
        try:
            payload = json.loads(body)
        except (ValueError, UnicodeDecodeError):
            raise Problem(400, "Malformed JSON")
        validate_payload(payload)
        result = self.store.ingest(payload)
        self.wake.set()
        return result

    def start(self):
        for i in range(2):
            t = threading.Thread(target=self.worker, name=f"relay-worker-{i}", daemon=True)
            self.threads.append(t)
            t.start()

    def request_crm(self, path, payload=None, headers=None):
        req = urllib.request.Request(self.origin+path, data=encode(payload) if payload is not None else None,
                                     headers={"Content-Type": "application/json", "X-Relay-Control": self.control, **(headers or {})})
        with urllib.request.urlopen(req, timeout=1) as response:
            return json.load(response)

    def worker(self):
        while not self.stop.is_set():
            if self.paused.is_set():
                self.stop.wait(.1)
                continue
            event = self.store.claim(self.lease_seconds)
            if event:
                try:
                    self.deliver(event)
                except Exception as exc:
                    # A programming/unexpected transport failure is an unknown outcome.
                    self.store.finish(event, "review", f"Unexpected delivery failure: {type(exc).__name__}; inspect before retry")
            else:
                self.wake.wait(.1)
                self.wake.clear()

    def deliver(self, event):
        key = hashlib.sha256(encode([event["tenant"], event["event_key"]])).hexdigest()
        safe = event["mode"] != "unsafe"
        if safe and event["attempts"] > 1:
            try:
                known = self.request_crm("/mock-crm/operations/"+key)
            except (urllib.error.URLError, RemoteDisconnected, TimeoutError, OSError):
                self.retry(event, "CRM lookup unavailable; no blind resend")
                return
            if known.get("id"):
                self.store.annotate(event, "reconciled", "Existing CRM receipt found; no second delivery")
                self.store.finish(event, "delivered", "Recovered from saved CRM receipt", known["id"])
                return
        payload = json.loads(event["payload"])
        contact = {k: payload[k] for k in ("tenant", "name", "email")}
        try:
            result = self.request_crm("/mock-crm/contacts", contact,
                                      {"Idempotency-Key": key, "X-Demo-Mode": event["mode"]})
            if event["mode"] == "worker_stop" and event["attempts"] == 1:
                self.store.annotate(event, "worker_stopped", "Worker stopped after CRM commit; acknowledgement not recorded")
                self.paused.set()
                return
            self.store.finish(event, "delivered", "CRM accepted contact", result["id"])
        except urllib.error.HTTPError as exc:
            if exc.code >= 500 or exc.code == 429:
                if safe:
                    self.retry(event, f"CRM returned {exc.code}; reconciling before the next attempt")
                else:
                    self.store.finish(event, "review", "CRM error without a safe retry contract; check externally")
            else:
                self.store.finish(event, "failed", f"CRM rejected contact ({exc.code}); permanent error")
        except (urllib.error.URLError, RemoteDisconnected, TimeoutError, OSError):
            self.store.annotate(event, "unknown", "CRM confirmation lost; delivery outcome unknown")
            if safe:
                self.retry(event, "Checking saved CRM receipt before retry")
            else:
                self.store.finish(event, "review", "CRM has no receipt lookup or idempotency contract; automatic retry stopped")

    def retry(self, event, message):
        if event["attempts"] >= 4:
            self.store.finish(event, "review", "Retry budget exhausted; " + message)
        else:
            self.store.finish(event, "retrying", message, delay=min(3, self.retry_base * 2**(event["attempts"]-1)))

    def demo(self, mode):
        if not isinstance(mode, str) or mode not in MODES:
            raise Problem(400, "Unknown scenario")
        suffix = uuid.uuid4().hex[:8]
        payload = {"event_id": "evt_"+suffix, "tenant": "northstar-demo", "name": "Morgan Chen",
                   "email": "morgan."+suffix+"@example.invalid", "mode": mode}
        body = encode(payload)
        signed = signature(body, self.secret)
        if mode == "duplicates":
            with ThreadPoolExecutor(max_workers=12) as pool:
                results = list(pool.map(lambda _: self.ingest(body, signed), range(12)))
        else:
            results = [self.ingest(body, signed)]
        return {"event_id": results[0]["id"], "submissions": len(results), "mode": mode}

    def snapshot(self):
        state = self.store.snapshot()
        state.update({"contacts": self.crm.contacts(), "worker_paused": self.paused.is_set(),
                      "server_time": time.time(), "version": "1.0.0"})
        return state

    def close(self):
        self.stop.set()
        self.wake.set()
        for t in self.threads:
            t.join(timeout=2)


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 128


class Handler(BaseHTTPRequestHandler):
    server_version = "RelayDemo/1.0"

    @property
    def app(self):
        return self.server.app

    def log_message(self, *_):
        pass

    def reply(self, value, status=200, content_type="application/json"):
        body = encode(value) if content_type == "application/json" else value.encode()
        self.send_response(status)
        self.send_header("Content-Type", content_type+"; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def gate(self, control=False):
        port = self.server.server_port
        if self.headers.get("Host") not in (f"127.0.0.1:{port}", f"localhost:{port}"):
            raise Problem(403, "Local demo host required")
        origin = self.headers.get("Origin")
        if origin and origin not in (f"http://127.0.0.1:{port}", f"http://localhost:{port}"):
            raise Problem(403, "Cross-origin requests are not permitted")
        if control and not hmac.compare_digest(self.headers.get("X-Relay-Control", ""), self.app.control):
            raise Problem(403, "Demo control token required")

    def body(self):
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise Problem(400, "Invalid content length")
        if not 0 < length <= 32768:
            raise Problem(413, "Request must be between 1 and 32768 bytes")
        self.connection.settimeout(3)
        return self.rfile.read(length)

    def json_body(self):
        try:
            result = json.loads(self.body())
            if not isinstance(result, dict):
                raise ValueError()
            return result
        except (ValueError, UnicodeDecodeError):
            raise Problem(400, "Expected a JSON object")

    def do_GET(self):
        try:
            self.gate()
            path = urllib.parse.urlsplit(self.path).path
            if path == "/":
                html = (ROOT/"static/index.html").read_text().replace("__CONTROL_TOKEN__", self.app.control)
                self.reply(html, content_type="text/html")
            elif path in ("/app.js", "/style.css"):
                self.reply((ROOT/"static"/path[1:]).read_text(), content_type="text/javascript" if path.endswith("js") else "text/css")
            elif path == "/api/state":
                self.reply(self.app.snapshot())
            elif path == "/api/health":
                self.reply({"ok": True, "workers": sum(t.is_alive() for t in self.app.threads), "local_demo": True})
            elif path.startswith("/mock-crm/operations/"):
                self.gate(control=True)
                self.reply(self.app.crm.lookup(path.rsplit("/", 1)[1]) or {})
            elif path == "/favicon.ico":
                self.reply("", status=204, content_type="image/x-icon")
            else:
                raise Problem(404, "Not found")
        except Problem as exc:
            self.reply({"error": exc.message}, exc.status)

    def do_POST(self):
        try:
            self.gate()
            path = urllib.parse.urlsplit(self.path).path
            if path == "/api/webhook":
                result = self.app.ingest(self.body(), self.headers.get("X-Relay-Signature", ""))
                self.reply(result, 200 if result["duplicate"] else 202)
                return
            self.gate(control=True)
            payload = self.json_body()
            if path == "/api/demo":
                if not self.app.demo_lock.acquire(blocking=False):
                    raise Problem(409, "A demo submission is already in progress")
                try:
                    self.reply(self.app.demo(payload.get("mode")), 202)
                finally:
                    self.app.demo_lock.release()
            elif path == "/api/worker":
                if payload.get("action") == "resume":
                    self.app.paused.clear()
                elif payload.get("action") == "pause":
                    self.app.paused.set()
                else:
                    raise Problem(400, "Expected pause or resume")
                self.app.wake.set()
                self.reply({"paused": self.app.paused.is_set()})
            elif path == "/mock-crm/contacts":
                key = self.headers.get("Idempotency-Key", "")
                mode = self.headers.get("X-Demo-Mode", "normal")
                if not key or mode not in MODES:
                    raise Problem(400, "Missing operation key or invalid scenario")
                status, result, disconnect = self.app.crm.upsert(payload, key, mode)
                if disconnect:
                    self.close_connection = True
                    return
                self.reply(result, status)
            else:
                raise Problem(404, "Not found")
        except Problem as exc:
            self.reply({"error": exc.message}, exc.status)
        except (TimeoutError, ConnectionResetError):
            self.close_connection = True


def make_server(data_dir, port=0, **options):
    app = Application(data_dir, **options)
    server = Server(("127.0.0.1", port), Handler)
    server.app = app
    app.origin = f"http://127.0.0.1:{server.server_port}"
    return server, app


def main():
    parser = argparse.ArgumentParser(description="Relay local demo")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--data-dir", type=Path, default=ROOT/"data")
    parser.add_argument("--lease-seconds", type=float, default=2)
    args = parser.parse_args()
    server, app = make_server(args.data_dir, args.port,
                            secret=os.environ.get("RELAY_WEBHOOK_SECRET", "relay-local-demo-secret"),
                            lease_seconds=args.lease_seconds)
    app.start()
    print(f"Relay running at {app.origin} (local demonstration)", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        app.close()
        server.server_close()


if __name__ == "__main__":
    main()
