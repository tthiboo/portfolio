"""Original synthetic documents and independent expected labels."""
from copy import deepcopy
from decimal import Decimal
import json
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import A4

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'output/pdf'
FIXTURES = ROOT/'fixtures'


def invoice(number, po, currency='EUR', quantity='10', unit='48.00', sku='SWT-01', locale='en-US', **updates):
    amount = (Decimal(quantity)*Decimal(unit)).quantize(Decimal('.01'))
    tax = (amount*Decimal('.20')).quantize(Decimal('.01')) if currency == 'EUR' else Decimal(0)
    return {'vendor_id':'V-ATLAS','invoice_number':number,'po_id':po,'currency':currency,
        'locale':locale,'date':'2026-10-09','subtotal':str(amount),'tax':str(tax),'total':str(amount+tax),
        'items':[{'sku':sku,'description':'Network equipment','quantity':quantity,'unit_price':unit,'amount':str(amount)}],**updates}


def formatted(value, locale):
    number = Decimal(value)
    digits = max(2, -number.as_tuple().exponent)
    text = f'{number:,.{digits}f}'
    return text.replace(',','_').replace('.',',').replace('_','.') if locale == 'de-DE' else text


def document_pdf(path, data, style='atlas', missing=(), blank=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    c = canvas.Canvas(str(path), pagesize=A4)
    c.setTitle(f"Synthetic invoice {data['invoice_number']}")
    c.setAuthor('Mark Newton - independent demonstration')
    width,height = A4
    c.setFillColor(HexColor('#142726'));c.rect(0,height-125,width,125,fill=1,stroke=0)
    c.setFillColor(HexColor('#a8d9cc'));c.setFont('Helvetica-Bold',10);c.drawString(42,height-42,'ATLAS NETWORK SUPPLY / DEMONSTRATION')
    c.setFillColor(HexColor('#ffffff'));c.setFont('Helvetica-Bold',32);c.drawString(42,height-88,'Invoice' if not blank else 'Document image placeholder')
    if blank:
        # A genuinely textless page: all lettering is absent from the PDF text layer.
        c = canvas.Canvas(str(path), pagesize=A4)
        c.setFillColor(HexColor('#e8ece8'));c.rect(42,70,width-84,height-140,fill=1,stroke=0)
        for y in range(140,700,35):
            c.setStrokeColor(HexColor('#c1cbc2'));c.line(70,y,width-70,y)
        c.save();return
    labels={'vendor_id':'Vendor ID','invoice_number':'Invoice no','po_id':'PO reference','currency':'Currency',
        'locale':'Number format','date':'Invoice date','subtotal':'Subtotal','tax':'Tax','total':'Total'}
    if style != 'atlas':
        labels.update(vendor_id='Supplier ID',invoice_number='Invoice number',po_id='Purchase order',
            currency='Currency code',locale='Numeric locale',date='Issued on',subtotal='Net amount',tax='Tax amount',total='Gross amount')
    keys=['vendor_id','invoice_number','po_id','currency','locale','date']
    if style == 'heldout':
        keys=['date','currency','invoice_number','locale','po_id','vendor_id']
    y=height-160
    c.setFillColor(HexColor('#263733'));c.setFont('Helvetica',11)
    for key in keys:
        if key not in missing:
            c.drawString(42,y,f'{labels[key]}: {data[key]}');y-=24 if style=='heldout' else 21
    y-=24
    c.setFillColor(HexColor('#e8f2eb'));c.rect(42,y-11,width-84,30,fill=1,stroke=0)
    c.setFillColor(HexColor('#263733'));c.setFont('Helvetica-Bold',9)
    c.drawString(50,y,'Line | SKU | Description | Qty | Unit | Amount')
    y-=35
    c.setFont('Helvetica',9)
    for index,row in enumerate(data['items'],1):
        c.drawString(50,y,' | '.join([str(index),row['sku'],row['description'],formatted(row['quantity'],data['locale']),formatted(row['unit_price'],data['locale']),formatted(row['amount'],data['locale'])]));y-=28
    y-=34
    c.setFont('Helvetica',12)
    for key in ('subtotal','tax','total'):
        if key not in missing:
            c.drawString(42,y,f'{labels[key]}: {formatted(data[key],data["locale"])}');y-=26
    c.setStrokeColor(HexColor('#d3ddd4'));c.line(42,100,width-42,100)
    c.setFillColor(HexColor('#68756e'));c.setFont('Helvetica',9)
    c.drawString(42,79,'Synthetic document. No real supplier, tax statement or payment obligation.')
    c.drawString(42,63,'Invoice Guard / Mark Newton / Independent engineering project')
    c.save()


def reference_pdf(path, record, kind):
    c=canvas.Canvas(str(path),pagesize=A4);width,height=A4
    c.setTitle(f"Synthetic {kind} {record.get('po_id')}")
    c.setFillColor(HexColor('#142726'));c.rect(0,height-120,width,120,fill=1,stroke=0)
    c.setFillColor(HexColor('#ffffff'));c.setFont('Helvetica-Bold',27);c.drawString(42,height-72,kind)
    c.setFillColor(HexColor('#263733'));c.setFont('Helvetica',12);y=height-155
    for key,value in record.items():
        if key != 'items':c.drawString(42,y,f'{key}: {value}');y-=23
    y-=20;c.setFont('Helvetica-Bold',11);c.drawString(42,y,'SKU / QUANTITY'+(' / UNIT PRICE' if kind=='Purchase order' else ''));y-=30;c.setFont('Helvetica',11)
    for row in record['items']:
        c.drawString(42,y,f"{row['sku']} / {row['quantity']}"+(f" / {row['unit_price']} {record['currency']}" if 'unit_price' in row else ''));y-=28
    c.setFont('Helvetica',9);c.setFillColor(HexColor('#68756e'));c.drawString(42,70,'Synthetic reference document. Machine-readable source: fixtures/reference.json.');c.save()


def build():
    FIXTURES.mkdir(exist_ok=True)
    OUT.mkdir(parents=True,exist_ok=True)
    specs=[('2101','EUR','100','60','48.00','SWT-01'),('2102','EUR','100','60','48.00','SWT-01'),
        ('2103','USD','20','8','25.00','HUB-02'),('2104','EUR','10','10','120.00','ADP-03'),
        ('2105','EUR','20','20','19.00','CAB-04'),('2106','EUR','20','20','75.00','RTR-05'),
        ('2107','EUR','100','100','48.00','SWT-01'),('2108','EUR','100','100','48.00','SWT-01')]
    orders=[];receipts=[]
    for code,currency,ordered,received,unit,sku in specs:
        po={'po_id':'PO-'+code,'vendor_id':'V-ATLAS','vendor_name':'Atlas Network Supply (fictional)',
            'currency':currency,'items':[{'sku':sku,'description':'Network equipment','quantity':ordered,'unit_price':unit}]}
        receipt={'receipt_id':'GR-'+code,'po_id':po['po_id'],'items':[{'sku':sku,'quantity':received}]}
        orders.append(po);receipts.append(receipt)
        reference_pdf(OUT/f'purchase-order-{code}.pdf',po,'Purchase order')
        reference_pdf(OUT/f'goods-receipt-{code}.pdf',receipt,'Goods receipt')
    (FIXTURES/'reference.json').write_text(json.dumps({'purchase_orders':orders,'receipts':receipts},indent=2)+'\n')
    samples={
        'clear':invoice('INV-2401','PO-2101'),
        'price':invoice('INV-2402','PO-2102',quantity='30',unit='54.00',locale='de-DE'),
        'quantity':invoice('INV-2403','PO-2103','USD',quantity='12',unit='25.00',sku='HUB-02'),
        'cumulative-first':invoice('INV-2404A','PO-2104',quantity='6',unit='120.00',sku='ADP-03'),
        'cumulative-second':invoice('INV-2404B','PO-2104',quantity='5',unit='120.00',sku='ADP-03'),
        'currency':invoice('INV-2405','PO-2105','USD',quantity='5',unit='19.00',sku='CAB-04'),
        'total':invoice('INV-2406','PO-2106',quantity='4',unit='75.00',sku='RTR-05',total='999.00'),
        'missing':invoice('INV-2407','PO-2107'),
        'duplicate':invoice('INV-2401','PO-2101',locale='de-DE'),
        'scan':invoice('INV-2408','PO-2108')}
    for key,data in samples.items():
        document_pdf(OUT/f'invoice-{key}.pdf',data,'folio' if key=='duplicate' else 'atlas',missing=('vendor_id',) if key=='missing' else (),blank=key=='scan')
    (FIXTURES/'sample-truth.json').write_text(json.dumps(samples,indent=2)+'\n')
    # Evaluation uses a different field order, larger spacing and alias labels.
    # Labels are fixed here, independently of the reconciliation engine.
    evaluation=[]
    for index in range(12):
        po_id=f'EVAL-{index:02}'
        data=invoice(f'HOLDOUT-{index:02}',po_id,quantity=str(3+index),unit='12.50',sku='EVAL-SKU',locale='de-DE' if index%2 else 'en-US')
        reference={'purchase_orders':[{'po_id':po_id,'vendor_id':'V-ATLAS','vendor_name':'Evaluation supplier (fictional)',
            'currency':'EUR','items':[{'sku':'EVAL-SKU','description':'Evaluation line','quantity':'100','unit_price':'12.50'}]}],
            'receipts':[{'receipt_id':f'REVAL-{index:02}','po_id':po_id,'items':[{'sku':'EVAL-SKU','quantity':'100'}]}]}
        expected=[]
        if index%4==1:
            data=invoice(data['invoice_number'],po_id,quantity=data['items'][0]['quantity'],unit='14.00',sku='EVAL-SKU',locale=data['locale']);expected=['PRICE_VARIANCE']
        elif index%4==2:
            reference['receipts'][0]['items'][0]['quantity']='2';expected=['RECEIPT_QUANTITY']
        elif index%4==3:
            data['total']='1.00';expected=['TOTAL_MISMATCH']
        path=OUT/f'evaluation-{index:02}.pdf';document_pdf(path,data,'heldout')
        evaluation.append({'pdf':str(path.relative_to(ROOT)),'truth':data,'reference':reference,'expected_codes':expected})
    (FIXTURES/'evaluation.json').write_text(json.dumps(evaluation,indent=2)+'\n')
    print(f'Generated {len(list(OUT.glob("*.pdf")))} original synthetic PDFs.')


if __name__=='__main__':build()
