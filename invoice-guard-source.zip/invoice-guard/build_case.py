"""One-page portfolio brief using recorded results and an actual UI capture."""
import json
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader

ROOT=Path(__file__).resolve().parent


def build():
    report=json.loads((ROOT/'portfolio/verification.json').read_text())
    output=ROOT/'output/pdf/invoice-guard-case.pdf'
    c=canvas.Canvas(str(output),pagesize=A4)
    c.setTitle('Invoice Guard - Independent engineering project');c.setAuthor('Mark Newton')
    width,height=A4;ink=HexColor('#333432');muted=HexColor('#786f61');paper=HexColor('#f3f1ed');gold=HexColor('#9f4939')
    c.setFillColor(paper);c.rect(0,0,width,height,fill=1,stroke=0)
    c.setFillColor(ink);c.setFont('Courier',8);c.drawString(40,804,'MARK NEWTON / RECONCILIATION NOTE / INDEPENDENT PROJECT')
    c.setFont('Times-Roman',30);c.drawString(40,772,'Invoice Guard')
    c.setFont('Helvetica',11);c.drawString(40,749,'Invoice, purchase order and receipt reconciliation.')
    cards=[(str(report['tests']['passed']),'AUTOMATED CHECKS'),
        (f"{report['synthetic_evaluation']['fields_correct']}/{report['synthetic_evaluation']['fields_checked']}",'SYNTHETIC FIELDS'),
        (str(report['synthetic_evaluation']['documents']),'EVALUATION PDFS')]
    for index,(number,label) in enumerate(cards):
        x=40+index*175;c.setStrokeColor(HexColor('#c5bfb5'));c.line(x,230,x+165,230)
        c.setFillColor(ink);c.setFont('Times-Roman',25);c.drawString(x,202,number)
        c.setFont('Helvetica',8);c.drawString(x,186,label)
    image=ImageReader(str(ROOT/'portfolio/01-price-finding.jpg'))
    c.drawImage(image,40,441,width=515,height=289.6875,preserveAspectRatio=True,mask='auto')
    c.setFillColor(muted);c.setFont('Helvetica',8);c.drawString(40,425,'Actual local demo: EUR 48 ordered, EUR 54 invoiced, 30 units. EUR 180 difference.')
    columns=[(40,'WHAT IT CHECKS',[
        'Exact decimal totals and unit prices.',
        'Ordered, received and previously billed quantities.',
        'Duplicate and conflicting invoice identifiers.',
        'Source page and text line for each finding.']),
        (314,'WHAT WAS VERIFIED',[
        '12/12 synthetic line matches.',
        'Nine expected rule findings; no extra or missed codes.',
        '24 concurrent copies: one record and one claim.',
        'History survives a restart. Missing fields stop.'])]
    for x,title,lines in columns:
        c.setFillColor(ink);c.setFont('Helvetica-Bold',9);c.drawString(x,389,title)
        c.setFillColor(muted);c.setFont('Helvetica',8.5)
        for index,line in enumerate(lines):c.drawString(x,366-index*19,line)
    c.setStrokeColor(HexColor('#c5bfb5'));c.line(40,129,555,129)
    c.setFillColor(ink);c.setFont('Helvetica-Bold',9);c.drawString(40,108,'Python / SQLite / PDF processing / HTTP APIs / JavaScript')
    c.setFillColor(muted);c.setFont('Helvetica',8)
    c.drawString(40,88,'Original synthetic documents. Supported text-PDF templates; no OCR or payment approval.')
    c.drawString(40,72,'Small synthetic evaluation, not real-supplier accuracy or customer savings. Source and tests included.')
    c.save();print(output)


if __name__=='__main__':build()
