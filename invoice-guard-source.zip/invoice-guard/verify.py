"""Run checks and record separately scored synthetic extraction/matching results."""
from datetime import datetime, timezone
from decimal import Decimal
from io import StringIO
import json
from pathlib import Path
import platform
import tempfile
import time
import unittest

from engine import Ledger
from app import ROOT


def verify():
    output=ROOT/'portfolio';output.mkdir(exist_ok=True)
    stream=StringIO();started=time.monotonic()
    suite=unittest.defaultTestLoader.discover(str(ROOT),pattern='test_guard.py')
    tests=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    (output/'test-results.txt').write_text(stream.getvalue())
    if not tests.wasSuccessful():
        print(stream.getvalue());raise SystemExit(1)
    field_correct=field_total=matched=tp=fp=fn=false_review=clean_total=0
    samples=[]
    for case in json.loads((ROOT/'fixtures/evaluation.json').read_text()):
        with tempfile.TemporaryDirectory() as directory:
            ledger=Ledger(Path(directory)/'evaluation.sqlite3');ledger.import_reference(case['reference'])
            tick=time.perf_counter();ledger.process((ROOT/case['pdf']).read_bytes(),'evaluation.pdf');elapsed=(time.perf_counter()-tick)*1000
            record=ledger.state()['invoices'][0];actual=record['document'];truth=case['truth']
            for key in ('vendor_id','invoice_number','po_id','currency','locale','date','subtotal','tax','total'):
                field_total+=1;field_correct+=actual['fields'].get(key)==truth[key]
            for row,expected in zip(actual['items'],truth['items']):
                for key in ('sku','description','quantity','unit_price','amount'):
                    field_total+=1
                    field_correct+=(Decimal(row[key])==Decimal(expected[key]) if key in ('quantity','unit_price','amount') else row[key]==expected[key])
            expected_codes=set(case['expected_codes']);observed={i['code'] for i in record['result']['issues']}
            tp+=len(expected_codes&observed);fp+=len(observed-expected_codes);fn+=len(expected_codes-observed)
            if not expected_codes:clean_total+=1;false_review+=record['status']=='review'
            matched+=len(record['result']['matches'])==len(truth['items']) and all(a['sku']==b['sku'] for a,b in zip(record['result']['matches'],truth['items']))
            samples.append({'pdf':case['pdf'],'expected_codes':sorted(expected_codes),'observed_codes':sorted(observed),'elapsed_ms':round(elapsed,3)})
    report={'recorded_at':datetime.now(timezone.utc).isoformat(),'python':platform.python_version(),'platform':platform.platform(),
        'tests':{'passed':tests.testsRun,'failed':len(tests.failures)+len(tests.errors),'duration_seconds':round(time.monotonic()-started,3)},
        'synthetic_evaluation':{'documents':len(samples),'layout':'Alias labels and reordered header layout; two explicit numeric locales',
            'fields_correct':field_correct,'fields_checked':field_total,'matched_documents':matched,
            'true_positive_rule_codes':tp,'false_positive_rule_codes':fp,'false_negative_rule_codes':fn,
            'rule_precision':tp/(tp+fp) if tp+fp else None,'rule_recall':tp/(tp+fn) if tp+fn else None,
            'clean_documents':clean_total,'clean_documents_sent_to_review':false_review,'samples':samples},
        'scope':'Small original synthetic evaluation. No real supplier, OCR, universal invoice accuracy or customer savings claimed.',
        'ui_verification':'Recorded separately after browser checks.'}
    (output/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(f'{tests.testsRun} tests passed; {field_correct}/{field_total} synthetic fields; {matched}/{len(samples)} line matches; rule TP/FP/FN {tp}/{fp}/{fn}.')


if __name__=='__main__':verify()
