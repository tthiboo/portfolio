"""Deterministic, evidence-linked invoice reconciliation. No payment decisions."""
from contextlib import contextmanager
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import hashlib
from io import BytesIO
import json
from pathlib import Path
import re
import sqlite3
import time

from pypdf import PdfReader

CENT = Decimal('.01')
FIELDS = {
    'vendor_id': ('Vendor ID', 'Supplier ID'),
    'invoice_number': ('Invoice no', 'Invoice number'),
    'po_id': ('PO reference', 'Purchase order'),
    'currency': ('Currency', 'Currency code'),
    'locale': ('Number format', 'Numeric locale'),
    'date': ('Invoice date', 'Issued on'),
    'subtotal': ('Subtotal', 'Net amount'), 'tax': ('Tax', 'Tax amount'),
    'total': ('Total', 'Gross amount'),
}


class InputError(ValueError):
    pass


def decimal(value, locale='en-US', monetary=False):
    if not isinstance(value, str) or len(value) > 40:
        raise InputError('Expected a bounded decimal string')
    value = value.strip().replace('\u00a0', ' ')
    if locale == 'en-US':
        pattern = r'(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d{1,3})?'
        normalized = value.replace(',', '')
    elif locale == 'de-DE':
        pattern = r'(?:\d{1,3}(?:\.\d{3})+|\d+)(?:,\d{1,3})?'
        normalized = value.replace('.', '').replace(',', '.')
    else:
        raise InputError('Unsupported or absent numeric locale')
    if not re.fullmatch(pattern, value):
        raise InputError('Ambiguous or unsupported number format')
    try:
        result = Decimal(normalized)
    except InvalidOperation:
        raise InputError('Invalid decimal')
    if not result.is_finite() or result < 0 or result > 10000000:
        raise InputError('Number outside demo limits')
    if monetary and result != result.quantize(CENT):
        raise InputError('Money must have at most two decimal places')
    return result


def money(value):
    return str(value.quantize(CENT, rounding=ROUND_HALF_UP))


def issue(code, summary, detail, sources=(), **extra):
    return {'code': code, 'summary': summary, 'detail': detail, 'sources': list(sources), **extra}


def extract_pdf(blob):
    if len(blob) > 2 * 1024 * 1024 or not blob.startswith(b'%PDF-'):
        raise InputError('Upload a PDF smaller than 2 MB')
    fields, evidence, rows, problems = {}, {}, [], []
    try:
        reader = PdfReader(BytesIO(blob))
        if reader.is_encrypted or not 1 <= len(reader.pages) <= 4:
            raise InputError('Encrypted PDFs and PDFs over four pages require review')
        for page_number, page in enumerate(reader.pages, 1):
            text = page.extract_text() or ''
            if len(text) > 50000:
                raise InputError('Text exceeds demo extraction limits')
            for line_number, raw in enumerate(text.splitlines(), 1):
                raw = raw.strip()
                source = {'page': page_number, 'line': line_number, 'text': raw}
                for key, labels in FIELDS.items():
                    for label in labels:
                        match = re.fullmatch(re.escape(label)+r'\s*:\s*(.*?)\s*', raw, re.I)
                        if match:
                            if key in fields:
                                problems.append(issue('AMBIGUOUS_FIELD', 'Repeated document field', f'{label} appears more than once; no value selected.', [evidence[key], source]))
                            else:
                                fields[key], evidence[key] = match[1], source
                if re.match(r'^\d+\s*\|', raw):
                    parts = [p.strip() for p in raw.split('|')]
                    if len(parts) != 6:
                        problems.append(issue('INVALID_LINE', 'Unreadable invoice line', 'Expected line / SKU / description / quantity / unit price / amount.', [source]))
                    else:
                        rows.append({'line': parts[0], 'sku': parts[1], 'description': parts[2],
                                     'quantity': parts[3], 'unit_price': parts[4], 'amount': parts[5], 'source': source})
    except InputError:
        raise
    except Exception:
        raise InputError('PDF could not be read; manual extraction required')
    if not fields and not rows:
        return {'fields':{},'evidence':{},'items':[],'extraction_issues':[issue('NO_TEXT_FIELDS','No supported invoice fields','Manual extraction required. OCR is not enabled.')]}
    for key in FIELDS:
        if not fields.get(key):
            problems.append(issue('MISSING_FIELD', 'Missing required field', key.replace('_', ' ')))
    if not rows:
        problems.append(issue('MISSING_LINES', 'No invoice lines extracted', 'The document cannot pass reconciliation without line items.'))
    locale = fields.get('locale')
    parsed_rows = []
    for row in rows:
        try:
            for key in ('quantity', 'unit_price', 'amount'):
                row[key] = str(decimal(row[key], locale, monetary=key != 'quantity'))
            if Decimal(row['quantity']) <= 0 or not re.fullmatch(r'[A-Za-z0-9_-]{1,40}', row['sku']):
                raise InputError('Unsupported SKU or nonpositive quantity')
            parsed_rows.append(row)
        except InputError as exc:
            problems.append(issue('INVALID_NUMBER', 'Invoice line needs extraction review', str(exc), [row['source']]))
    for key in ('subtotal', 'tax', 'total'):
        if key in fields:
            try:
                fields[key] = money(decimal(fields[key], locale, monetary=True))
            except InputError as exc:
                problems.append(issue('INVALID_NUMBER', 'Amount needs extraction review', f'{key}: {exc}', [evidence[key]]))
                fields.pop(key)
    if fields.get('currency') and fields['currency'] not in ('EUR', 'USD'):
        problems.append(issue('UNSUPPORTED_CURRENCY', 'Currency needs review', 'This demo supports explicitly labelled EUR and USD only.'))
    for key in ('vendor_id', 'invoice_number', 'po_id'):
        if key in fields and not re.fullmatch(r'[A-Za-z0-9_-]{1,60}', fields[key]):
            problems.append(issue('INVALID_IDENTIFIER', 'Identifier needs review', key))
    if 'date' in fields:
        try:
            import datetime
            datetime.date.fromisoformat(fields['date'])
        except ValueError:
            problems.append(issue('INVALID_DATE', 'Invoice date needs review', 'Expected an ISO calendar date.', [evidence['date']]))
    return {'fields': fields, 'evidence': evidence, 'items': parsed_rows, 'extraction_issues': problems}


def fingerprint(document, include_number=True):
    fields = {key: document['fields'].get(key) for key in ('vendor_id','invoice_number','po_id','currency','date','subtotal','tax','total') if include_number or key != 'invoice_number'}
    items = [{key: row[key] for key in ('sku', 'quantity', 'unit_price', 'amount')} for row in document['items']]
    for row in items:
        for key in ('quantity', 'unit_price', 'amount'):
            row[key] = str(Decimal(row[key]).normalize())
    return hashlib.sha256(json.dumps({'fields': fields, 'items': items}, sort_keys=True).encode()).hexdigest()


def validate_reference(pack):
    if not isinstance(pack, dict) or set(pack) != {'purchase_orders', 'receipts'}:
        raise InputError('Reference JSON needs purchase_orders and receipts')
    if not isinstance(pack['purchase_orders'], list) or not isinstance(pack['receipts'], list):
        raise InputError('Expected reference lists')
    if not 1 <= len(pack['purchase_orders']) <= 100 or len(pack['receipts']) > 500:
        raise InputError('Reference count outside demo limits')
    orders, receipts = {}, {}
    for po in pack['purchase_orders']:
        if not isinstance(po, dict) or set(po) != {'po_id','vendor_id','vendor_name','currency','items'}:
            raise InputError('Invalid purchase order fields')
        for key in ('po_id','vendor_id'):
            if not isinstance(po[key], str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,60}', po[key]):
                raise InputError('Invalid reference identifier')
        if not isinstance(po['vendor_name'], str) or not 1 <= len(po['vendor_name']) <= 100:
            raise InputError('Invalid vendor name')
        if not isinstance(po['currency'],str) or po['currency'] not in ('USD','EUR') or not isinstance(po['items'], list) or not 1 <= len(po['items']) <= 100:
            raise InputError('Unsupported currency or item list')
        seen = set()
        for item in po['items']:
            if not isinstance(item, dict) or set(item) != {'sku','description','quantity','unit_price'}:
                raise InputError('Invalid purchase order line')
            if not isinstance(item['sku'], str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,40}', item['sku']) or item['sku'] in seen:
                raise InputError('Duplicate or invalid reference SKU')
            if not isinstance(item['description'], str) or not 1 <= len(item['description']) <= 120:
                raise InputError('Invalid item description')
            if decimal(item['quantity']) <= 0:
                raise InputError('Quantity must be positive')
            decimal(item['unit_price'], monetary=True)
            seen.add(item['sku'])
        if po['po_id'] in orders:
            raise InputError('Duplicate purchase order identifier')
        orders[po['po_id']] = po
    for receipt in pack['receipts']:
        if not isinstance(receipt, dict) or set(receipt) != {'receipt_id','po_id','items'}:
            raise InputError('Invalid receipt fields')
        if not isinstance(receipt['receipt_id'], str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,60}', receipt['receipt_id']) or receipt['receipt_id'] in receipts:
            raise InputError('Invalid or duplicate receipt identifier')
        if not isinstance(receipt['po_id'],str) or receipt['po_id'] not in orders or not isinstance(receipt['items'], list) or not 1 <= len(receipt['items']) <= 100:
            raise InputError('Unknown receipt purchase order or missing receipt lines')
        allowed = {i['sku'] for i in orders[receipt['po_id']]['items']}
        for row in receipt['items']:
            if not isinstance(row, dict) or set(row) != {'sku','quantity'} or not isinstance(row['sku'],str) or row['sku'] not in allowed or decimal(row['quantity']) <= 0:
                raise InputError('Invalid receipt quantity or SKU')
        receipts[receipt['receipt_id']] = receipt
    return pack


class Ledger:
    def __init__(self, path):
        self.path = str(path)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.execute('PRAGMA journal_mode=WAL')
            db.executescript('''
                CREATE TABLE IF NOT EXISTS orders(po_id TEXT PRIMARY KEY, document TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS receipts(receipt_id TEXT PRIMARY KEY, po_id TEXT NOT NULL, document TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS invoices(id INTEGER PRIMARY KEY, digest TEXT NOT NULL UNIQUE,
                  filename TEXT NOT NULL, pdf BLOB NOT NULL, document TEXT NOT NULL, result TEXT NOT NULL,
                  status TEXT NOT NULL, fingerprint TEXT, at REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS identities(vendor_id TEXT, invoice_number TEXT, invoice_id INTEGER,
                  PRIMARY KEY(vendor_id,invoice_number), FOREIGN KEY(invoice_id) REFERENCES invoices(id));
                CREATE TABLE IF NOT EXISTS claims(invoice_id INTEGER, po_id TEXT, sku TEXT, quantity TEXT,
                  FOREIGN KEY(invoice_id) REFERENCES invoices(id));
                CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, invoice_id INTEGER, message TEXT, at REAL);
            ''')

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        try:
            yield db
        finally:
            db.close()

    @contextmanager
    def transaction(self):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            try:
                yield db
                db.execute('COMMIT')
            except BaseException:
                db.execute('ROLLBACK')
                raise

    def import_reference(self, pack):
        validate_reference(pack)
        with self.transaction() as db:
            for po in pack['purchase_orders']:
                existing = db.execute('SELECT document FROM orders WHERE po_id=?', (po['po_id'],)).fetchone()
                text = json.dumps(po, sort_keys=True)
                if existing and existing[0] != text:
                    raise InputError('Existing purchase order cannot be overwritten in this demo')
                db.execute('INSERT OR IGNORE INTO orders VALUES(?,?)', (po['po_id'], text))
            for receipt in pack['receipts']:
                existing = db.execute('SELECT document FROM receipts WHERE receipt_id=?', (receipt['receipt_id'],)).fetchone()
                text = json.dumps(receipt, sort_keys=True)
                if existing and existing[0] != text:
                    raise InputError('Existing receipt cannot be overwritten in this demo')
                db.execute('INSERT OR IGNORE INTO receipts VALUES(?,?,?)', (receipt['receipt_id'], receipt['po_id'], text))
            db.execute('INSERT INTO audit(invoice_id,message,at) VALUES(NULL,?,?)', ('Reference pack imported without overwriting existing records', time.time()))

    def process(self, blob, filename):
        if not isinstance(filename, str) or len(filename) > 200:
            raise InputError('Invalid filename')
        digest = hashlib.sha256(blob).hexdigest()
        try:
            document = extract_pdf(blob)
        except InputError as exc:
            document = {'fields': {}, 'evidence': {}, 'items': [], 'extraction_issues': [issue('UNREADABLE_DOCUMENT','Document needs manual extraction',str(exc))]}
        fields = document['fields']
        with self.transaction() as db:
            prior = db.execute('SELECT id FROM invoices WHERE digest=?', (digest,)).fetchone()
            if prior:
                db.execute('INSERT INTO audit(invoice_id,message,at) VALUES(?,?,?)', (prior[0], 'Exact file replay blocked; no new billing claim', time.time()))
                return {'id': prior[0], 'repeat': True}
            problems = list(document['extraction_issues'])
            matched, allocations, variance = [], [], Decimal(0)
            identity = None
            current_fingerprint = fingerprint(document)
            complete = not problems
            if fields.get('vendor_id') and fields.get('invoice_number'):
                identity = db.execute('''SELECT i.id,i.document FROM identities d JOIN invoices i ON d.invoice_id=i.id
                    WHERE d.vendor_id=? AND d.invoice_number=?''', (fields['vendor_id'],fields['invoice_number'])).fetchone()
            if identity:
                same = fingerprint(json.loads(identity['document'])) == current_fingerprint
                problems.append(issue('DUPLICATE_IDENTIFIER' if same else 'CONFLICTING_IDENTIFIER',
                    'Invoice identifier already submitted' if same else 'Invoice identifier has conflicting content',
                    f"Compare with invoice record #{identity['id']}; no additional quantity reserved.",
                    [document['evidence'].get('invoice_number', {})], related_invoice=identity['id']))
            po_row = db.execute('SELECT document FROM orders WHERE po_id=?', (fields.get('po_id'),)).fetchone()
            po = json.loads(po_row[0]) if po_row else None
            if not po and fields.get('po_id'):
                problems.append(issue('PO_NOT_FOUND','Purchase order not found','No reference order matches the extracted PO identifier.', [document['evidence'].get('po_id',{})]))
            elif po and fields.get('vendor_id') and fields['vendor_id'] != po['vendor_id']:
                problems.append(issue('VENDOR_MISMATCH','Supplier differs from purchase order','Supplier identifiers must match exactly.', [document['evidence'].get('vendor_id',{})]))
            elif po and fields.get('currency') and fields['currency'] != po['currency']:
                problems.append(issue('CURRENCY_MISMATCH','Currency differs from purchase order',f"Invoice: {fields.get('currency')}; purchase order: {po['currency']}. No FX conversion or quantity reservation performed.", [document['evidence'].get('currency',{})]))
            compatible = po and fields.get('vendor_id') == po['vendor_id'] and fields.get('currency') == po['currency']
            arithmetic_ok = complete
            if complete:
                subtotal = sum((Decimal(i['amount']) for i in document['items']), Decimal(0))
                if subtotal != Decimal(fields['subtotal']):
                    arithmetic_ok = False
                    problems.append(issue('SUBTOTAL_MISMATCH','Line amounts do not equal subtotal',f"Calculated {money(subtotal)}; document {fields['subtotal']}.",[document['evidence']['subtotal']]))
                expected_total = Decimal(fields['subtotal'])+Decimal(fields['tax'])
                if expected_total != Decimal(fields['total']):
                    arithmetic_ok = False
                    problems.append(issue('TOTAL_MISMATCH','Invoice total does not add up',f"Subtotal {fields['subtotal']} + tax {fields['tax']} = {money(expected_total)}; document {fields['total']}.",[document['evidence']['subtotal'],document['evidence']['tax'],document['evidence']['total']]))
            seen_quantities = {}
            for item in document['items']:
                qty, unit, amount = (Decimal(item[k]) for k in ('quantity','unit_price','amount'))
                calculated = money(qty*unit)
                if Decimal(calculated) != amount:
                    arithmetic_ok = False
                    problems.append(issue('LINE_ARITHMETIC','Line amount does not add up',f"{qty} x {unit} = {calculated}; document {amount}.",[item['source']],sku=item['sku']))
                if not compatible:
                    continue
                reference = next((r for r in po['items'] if r['sku'] == item['sku']), None)
                if not reference:
                    problems.append(issue('UNKNOWN_SKU','Invoice SKU is absent from the purchase order',item['sku'],[item['source']],sku=item['sku']))
                    arithmetic_ok = False
                    continue
                received = Decimal(0)
                for receipt_row in db.execute('SELECT document FROM receipts WHERE po_id=?',(po['po_id'],)):
                    received += sum((Decimal(r['quantity']) for r in json.loads(receipt_row[0])['items'] if r['sku'] == item['sku']), Decimal(0))
                prior_qty = sum((Decimal(r[0]) for r in db.execute('SELECT quantity FROM claims WHERE po_id=? AND sku=?',(po['po_id'],item['sku']))),Decimal(0))
                seen_quantities[item['sku']] = seen_quantities.get(item['sku'],Decimal(0))+qty
                claimed = prior_qty+seen_quantities[item['sku']]
                delta = Decimal(money((unit-Decimal(reference['unit_price']))*qty))
                if unit != Decimal(reference['unit_price']):
                    variance += delta
                    problems.append(issue('PRICE_VARIANCE','Unit price differs from purchase order',f"PO {reference['unit_price']}; invoice {money(unit)} x {qty} units. Difference {money(delta)} {fields['currency']}.",[item['source']],sku=item['sku'],amount=money(delta),currency=fields['currency'],po_unit_price=reference['unit_price'],invoice_unit_price=money(unit),quantity=str(qty)))
                if not identity and claimed > Decimal(reference['quantity']):
                    problems.append(issue('ORDER_QUANTITY','Cumulative invoiced quantity exceeds the order',f"Previously submitted {prior_qty}; this invoice {seen_quantities[item['sku']]}; ordered {reference['quantity']}.",[item['source']],sku=item['sku']))
                if not identity and claimed > received:
                    problems.append(issue('RECEIPT_QUANTITY','Cumulative invoiced quantity exceeds receipts',f"Previously submitted {prior_qty}; this invoice {seen_quantities[item['sku']]}; received {received}. Excess {claimed-received} units.",[item['source']],sku=item['sku'],excess=str(claimed-received)))
                matched.append({**item,'ordered_quantity':reference['quantity'],'received_quantity':str(received),
                    'previous_quantity':str(prior_qty),'cumulative_quantity':str(claimed),'po_unit_price':reference['unit_price'],
                    'price_variance':money(delta),'po_description':reference['description']})
                allocations.append((po['po_id'],item['sku'],str(qty)))
            # New numbers with otherwise identical commercial content are suspicious, not proven fraud.
            if complete and not identity:
                for previous in db.execute('SELECT id,document FROM invoices WHERE status IN (\'clear\',\'review\')'):
                    other = json.loads(previous['document'])
                    if not other['extraction_issues'] and fingerprint(other,False) == fingerprint(document,False):
                        problems.append(issue('POSSIBLE_DUPLICATE','Same billing content under another invoice number',f"Compare with record #{previous['id']}; held for review, no new quantity reserved.",related_invoice=previous['id']))
                        identity = previous
                        break
            status = 'review' if problems else 'clear'
            result = {'issues':problems,'matches':matched,'price_variance':money(variance) if not identity else '0.00',
                      'po':po,'reserved':bool(complete and compatible and arithmetic_ok and not identity),
                      'scope':'Technical reconciliation only; no payment approval.'}
            cursor = db.execute('INSERT INTO invoices(digest,filename,pdf,document,result,status,fingerprint,at) VALUES(?,?,?,?,?,?,?,?)',
                (digest,Path(filename).name,blob,json.dumps(document),json.dumps(result),status,current_fingerprint,time.time()))
            invoice_id = cursor.lastrowid
            if fields.get('vendor_id') and fields.get('invoice_number') and not identity:
                db.execute('INSERT OR IGNORE INTO identities VALUES(?,?,?)',(fields['vendor_id'],fields['invoice_number'],invoice_id))
            if result['reserved']:
                db.executemany('INSERT INTO claims VALUES(?,?,?,?)',[(invoice_id,*row) for row in allocations])
            db.execute('INSERT INTO audit(invoice_id,message,at) VALUES(?,?,?)',(invoice_id,
                f"{len(document['items'])} extracted lines; {len(problems)} checks need review; claims {'reserved' if result['reserved'] else 'not reserved'}",time.time()))
            return {'id':invoice_id,'repeat':False}

    def state(self):
        with self.connect() as db:
            db.execute('BEGIN')
            invoices = []
            for row in db.execute('SELECT id,filename,document,result,status,at FROM invoices ORDER BY id DESC LIMIT 200'):
                item = dict(row)
                item['document'],item['result'] = json.loads(item['document']),json.loads(item['result'])
                invoices.append(item)
            counts = dict(db.execute('SELECT status,COUNT(*) FROM invoices GROUP BY status'))
            variances = {}
            for row in db.execute('SELECT document,result FROM invoices'):
                document,result = json.loads(row[0]),json.loads(row[1])
                currency = document['fields'].get('currency')
                if currency in ('USD','EUR'):
                    variances[currency] = money(Decimal(variances.get(currency,'0'))+Decimal(result['price_variance']))
            return {'invoices':invoices,'metrics':{'processed':sum(counts.values()),'clear':counts.get('clear',0),
                'review':counts.get('review',0),'price_variances':variances},
                'orders':[json.loads(r[0]) for r in db.execute('SELECT document FROM orders ORDER BY po_id')],
                'receipts':[json.loads(r[0]) for r in db.execute('SELECT document FROM receipts ORDER BY receipt_id')],
                'audit':[dict(r) for r in db.execute('SELECT * FROM audit ORDER BY id DESC LIMIT 30')]}

    def pdf(self, invoice_id):
        with self.connect() as db:
            row = db.execute('SELECT pdf FROM invoices WHERE id=?',(invoice_id,)).fetchone()
            return bytes(row[0]) if row else None
