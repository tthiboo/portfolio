# Invoice Guard — Invoice & PO Reconciliation

**Independent engineering project · Mark Newton**

## Project description

I built a document review tool that compares invoices with purchase orders, delivery receipts and quantities already billed.

It extracts supported text PDFs, checks exact decimal arithmetic, matches SKUs and flags price differences, excess quantities, conflicting identifiers and possible duplicates. Each finding shows its rule, calculation and source line. Records and original documents survive a restart.

Verified on 12 original synthetic PDFs: 168 fields checked, all extracted correctly; all line matches and nine expected rule findings matched the labels. Nineteen automated tests cover persistence, concurrent replays, ambiguous fields and upload controls.

Python, SQLite, PDF processing, HTTP APIs, JavaScript. Local working demo and source included. Supported templates; OCR and payment approval are outside scope.

## Evidence

- EUR 48 ordered, EUR 54 invoiced, 30 units: EUR 180 synthetic price difference.
- Two invoices for 6 and 5 units against 10 received: cumulative excess detected.
- The same invoice in two layouts: duplicate identifier found, no second quantity reservation.
- Twenty-four simultaneous copies: one persisted invoice and one quantity claim.
- Missing fields, unreadable or encrypted PDFs: review instead of invented data.

The tests use fictional documents. No customer savings, commercial implementation or universal extraction accuracy is claimed.

## Demo sequence

1. Run price scenario. Inspect order/invoice unit prices and source text.
2. Switch to Line match and Source fields.
3. Run cumulative scenario: inspect previous 6 plus current 5 versus received 10.
4. Run duplicate scenario: compare the two PDFs and retained invoice identity.

## Russian copy

Инструмент сверки счетов с заказами и поступлениями. Проверяет цены, арифметику, количество с учетом предыдущих счетов и повторные документы. Для каждого расхождения показывает расчет и строку исходного PDF. История и документы сохраняются после перезапуска.

19 автоматических проверок. На 12 синтетических PDF корректно извлечены 168 проверяемых полей и найдены все заданные расхождения. Самостоятельный проект; поддерживаемые шаблоны, без OCR и банковских операций.


## Interface

The interface centres on a structured document reader: invoice text, imported purchase orders and receipts share the review desk. Original PDF links remain available; this is not a rendered PDF facsimile.
