"""Local Invoice Guard HTTP application."""
import argparse
import base64
import binascii
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hmac
import json
from pathlib import Path
import secrets
import urllib.parse

from engine import InputError, Ledger

ROOT=Path(__file__).resolve().parent
SCENARIOS={'clear':['clear'],'price':['price'],'quantity':['quantity'],
    'cumulative':['cumulative-first','cumulative-second'],'duplicate':['clear','duplicate'],
    'currency':['currency'],'total':['total'],'missing':['missing'],'scan':['scan']}


class Application:
    def __init__(self,data_dir):
        self.ledger=Ledger(Path(data_dir)/'invoices.sqlite3')
        self.token=secrets.token_urlsafe(32)
        self.ledger.import_reference(json.loads((ROOT/'fixtures/reference.json').read_text()))

    def demo(self,mode):
        if not isinstance(mode,str) or mode not in SCENARIOS:raise InputError('Unknown scenario')
        results=[self.ledger.process((ROOT/'output/pdf'/f'invoice-{name}.pdf').read_bytes(),f'invoice-{name}.pdf') for name in SCENARIOS[mode]]
        return {'id':results[-1]['id'],'repeat':all(r['repeat'] for r in results),'processed':len(results)}


class Server(ThreadingHTTPServer):
    daemon_threads=True
    allow_reuse_address=True
    request_queue_size=128


class Handler(BaseHTTPRequestHandler):
    server_version='InvoiceGuardDemo/1.0'
    def log_message(self,*args):pass

    def gate(self,write=False):
        origins=(f'http://127.0.0.1:{self.server.server_port}',f'http://localhost:{self.server.server_port}')
        if self.headers.get('Host') not in tuple(urllib.parse.urlsplit(o).netloc for o in origins):
            raise PermissionError('Local demo host required')
        if self.headers.get('Origin') and self.headers['Origin'] not in origins:
            raise PermissionError('Cross-origin request blocked')
        try:valid=hmac.compare_digest(self.headers.get('X-Guard-Control',''),self.server.app.token)
        except TypeError:valid=False
        if write and not valid:raise PermissionError('Local control token required')

    def reply(self,value,status=200,kind='application/json'):
        blob=json.dumps(value,separators=(',',':')).encode() if kind=='application/json' else value.encode() if isinstance(value,str) else value
        self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(blob)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-src 'self'; frame-ancestors 'none'")
        self.end_headers()
        try:self.wfile.write(blob)
        except (BrokenPipeError,ConnectionResetError):pass

    def body(self):
        try:length=int(self.headers.get('Content-Length','0'))
        except ValueError:raise InputError('Invalid content length')
        if not 0<length<=3*1024*1024:raise InputError('Request size outside demo limits')
        self.connection.settimeout(5)
        try:value=json.loads(self.rfile.read(length))
        except (ValueError,UnicodeDecodeError):raise InputError('Expected JSON')
        if not isinstance(value,dict):raise InputError('Expected JSON object')
        return value

    def do_GET(self):
        try:
            self.gate();path=urllib.parse.urlsplit(self.path).path
            if path=='/':self.reply((ROOT/'static/index.html').read_text().replace('__TOKEN__',self.server.app.token),kind='text/html; charset=utf-8')
            elif path in ('/style.css','/app.js'):
                self.reply((ROOT/'static'/path[1:]).read_text(),kind='text/css' if path.endswith('css') else 'text/javascript')
            elif path in ('/api/state','/api/export'):self.reply(self.server.app.ledger.state())
            elif path=='/api/health':self.reply({'ok':True,'local_demo':True})
            elif path.startswith('/documents/') and path.endswith('.pdf'):
                try:invoice_id=int(path.rsplit('/',1)[-1][:-4])
                except ValueError:raise InputError('Invalid document identifier')
                blob=self.server.app.ledger.pdf(invoice_id)
                if blob is None:self.reply({'error':'Not found'},404)
                else:self.reply(blob,kind='application/pdf')
            elif path.startswith('/samples/'):
                name=path.rsplit('/',1)[-1]
                allowed={p.name:p for p in (ROOT/'output/pdf').glob('*.pdf')}
                if name not in allowed:self.reply({'error':'Not found'},404)
                else:self.reply(allowed[name].read_bytes(),kind='application/pdf')
            elif path=='/reference.json':self.reply(json.loads((ROOT/'fixtures/reference.json').read_text()))
            elif path=='/favicon.ico':self.reply(b'',204,kind='image/x-icon')
            else:self.reply({'error':'Not found'},404)
        except PermissionError as exc:self.reply({'error':str(exc)},403)
        except InputError as exc:self.reply({'error':str(exc)},400)

    def do_POST(self):
        try:
            self.gate(write=True);payload=self.body();path=urllib.parse.urlsplit(self.path).path
            if path=='/api/demo':self.reply(self.server.app.demo(payload.get('mode')),202)
            elif path=='/api/upload':
                encoded=payload.get('pdf_base64')
                if not isinstance(encoded,str):raise InputError('Expected a base64 PDF')
                try:blob=base64.b64decode(encoded,validate=True)
                except (ValueError,binascii.Error):raise InputError('Invalid base64 PDF')
                if not blob or len(blob)>2*1024*1024:raise InputError('PDF size outside demo limits')
                self.reply(self.server.app.ledger.process(blob,payload.get('filename','upload.pdf')),202)
            elif path=='/api/reference':
                self.server.app.ledger.import_reference(payload);self.reply({'imported':True})
            else:self.reply({'error':'Not found'},404)
        except PermissionError as exc:self.reply({'error':str(exc)},403)
        except InputError as exc:self.reply({'error':str(exc)},400)
        except (TimeoutError,ConnectionResetError):self.close_connection=True


def make_server(data_dir,port=0):
    server=Server(('127.0.0.1',port),Handler);server.app=Application(data_dir);return server


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=8771);parser.add_argument('--data-dir',type=Path,default=ROOT/'data')
    args=parser.parse_args();server=make_server(args.data_dir,args.port)
    print(f'Invoice Guard: http://127.0.0.1:{server.server_port} (local demo)',flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
