# Invoice Guard

Invoice, purchase order and goods-receipt reconciliation. Independent project by Mark Newton.

**Working local app. Original synthetic PDFs. No external API or paid service.**

## Run

Python 3.11+, with `pypdf`. `reportlab` is only needed to regenerate fixtures and the portfolio PDF.

```sh
python3 -m pip install -r requirements.txt
python3 app.py
```

Open http://127.0.0.1:8771. On the machine used to create this project, `pypdf` is already installed. `Launch Invoice Guard.command` starts the app on macOS.

```sh
python3 verify.py
```

The test suite creates temporary databases and local HTTP ports. It does not alter the demonstration ledger. Results are recorded in `portfolio/verification.json` and `portfolio/test-results.txt`.

## Demo

| Scenario | Check |
|---|---|
| Price | EUR 48 ordered vs EUR 54 invoiced, 30 units: EUR 180 difference |
| Quantity | 12 invoiced, 8 received: 4 units exceed receipts |
| Cumulative | First invoice 6, second invoice 5, order/receipt 10: second invoice held |
| Duplicate | Same identifier and billing content in a different PDF layout: no new quantity reserved |
| Currency | USD invoice against EUR order: held, no conversion |
| Total | Subtotal plus stated tax differs from stated total |
| Missing | Supplier identifier absent: extraction review, not a fabricated supplier match |
| Textless | PDF with no supported text fields: manual extraction |

Upload a PDF with the supported structure or import a JSON reference pack. `fixtures/reference.json` is the schema example. Existing orders and receipts cannot be overwritten. Machine-readable JSON is the comparison authority; the sample reference PDFs are views generated from that same JSON.

## Supported input

The deterministic extractor recognizes the labelled fields and pipe-separated line structure shown in `output/pdf/invoice-clear.pdf`, plus the alias labels and alternate header ordering in the evaluation documents. It requires explicit `en-US` or `de-DE` number formatting, ISO dates, supplier/PO identifiers, EUR/USD currency, stated subtotal/tax/total and at least one line.

This is **not** a general-purpose invoice extractor. Scans need OCR, other layouts need an extraction adapter. Unknown, missing, repeated and unsupported fields are held for review. It does not infer tax rules, exchange rates or quantities from incomplete data. Limits: 2 MB, four PDF pages, bounded decimal values; credit notes and negative quantities are unsupported.

## Rules and persistence

- Decimal arithmetic, two decimal places for money, `ROUND_HALF_UP` for line extensions. Fractional quantities are supported to three decimals.
- Exact SKU matching, supplier and currency checks, per-line arithmetic, subtotal and total checks.
- Cumulative quantity checked against both ordered and received quantity.
- SHA-256 file replay protection. Business identifiers detect duplicates and conflicting content. Identical billing content under a new number is a **possible** duplicate, not a fraud conclusion.
- SQLite transactions serialize submissions so concurrent file replays cannot reserve multiple claims.
- Original PDFs, extracted fields, source page/text-line references, findings and history persist across restarts.
- Every finding contains a rule code, reason and available invoice evidence. Order/receipt data is visible in the line comparison and downloadable reference pack.

### Submitted claims are not approvals

A complete, arithmetically valid, supplier/currency-compatible unique invoice reserves its recognized quantities **even if it has a price or quantity finding**. This prevents later invoices from silently ignoring amounts already submitted for review. Incomplete, invalid, duplicate, conflicting and currency-incompatible records reserve no quantity. The UI exposes this distinction.

There is no approval, rejection, payment, override, deletion or claim-release operation. A real deployment needs an explicit reviewer workflow for corrections and reversals. A `clear` result means only that the supported technical checks found no issue.

The price-difference card adds signed unit-price differences by currency, excluding duplicate identifiers. It does not estimate customer savings or add currencies together. The demo contains synthetic differences only.

## Verification

19 automated tests passed. The separate fixed synthetic evaluation contains 12 alternate-layout PDFs: 168/168 labelled fields, 12/12 SKU matches, nine expected rule findings detected, zero extra or missed rule codes, zero clean documents held among three clean documents.

These counts describe a small, original synthetic set. They do not establish accuracy on real supplier documents. The evaluation was generated and labelled separately from the rule outputs; it is not an independent external audit or a model training benchmark. Per-document measurements and runtime are in the JSON report.

## Architecture

```mermaid
flowchart LR
    A[PDF upload] --> B[Text extraction + field evidence]
    B --> C[Decimal checks + exact SKU match]
    D[PO and receipt JSON] --> C
    E[(Prior submitted quantities)] --> C
    C --> F[(SQLite records + original PDFs)]
    F --> G[Review desk / evidence export]
```

All services stay on loopback. Browser writes require a per-process control token and local Host/Origin checks. The local page exposes that token for its controls; this is not production authentication. Python's development HTTP server and in-process PDF parsing are local-demo components, not a public upload service. Production requires proper authentication, isolated PDF processing, vendor adapters and operational controls.

No PDF or account information is sent to an external service. The dashboard shows the latest 200 records; counts include the full ledger.

## Files

- `portfolio/case.md`: copy for a portfolio project.
- `portfolio/verification.json`: functional and synthetic evaluation results.
- `portfolio/*.jpg`: captured UI states.
- `output/pdf/invoice-guard-case.pdf`: one-page project brief, when generated.
- `portfolio/invoice-guard-source.zip`: source, documents and evidence bundle, when generated.

## References

The problem was selected from an [invoice processing automation brief](https://www.upwork.com/freelance-jobs/apply/Invoice-Processing-Automation-Specialist_~022100421528346026931/) and compared with the public [invoice-agent example](https://github.com/superintelligenceco/invoice-agent). Our implementation, templates, documents, expected labels and measured results are original. No code, PDFs or reported performance from that repository was reused. Neither source is a client or endorsement.

[Python decimal](https://docs.python.org/3/library/decimal.html), [pypdf text extraction](https://pypdf.readthedocs.io/en/stable/user/extract-text.html), [SQLite transactions](https://www.sqlite.org/lang_transaction.html).


## Interface

The interface centres on a structured document reader: invoice text, imported purchase orders and receipts share the review desk. Original PDF links remain available; this is not a rendered PDF facsimile.
