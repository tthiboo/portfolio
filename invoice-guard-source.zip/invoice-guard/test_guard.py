import base64
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from decimal import Decimal
from io import BytesIO
import json
from pathlib import Path
import tempfile
import threading
import unittest
import urllib.error
import urllib.request

from pypdf import PdfReader, PdfWriter
from pypdf.generic import DecodedStreamObject, DictionaryObject, NameObject
from app import ROOT, make_server
from engine import InputError, Ledger, decimal, extract_pdf, money


def changed_pdf(original,replacements):
    text=PdfReader(BytesIO(original)).pages[0].extract_text()
    for before,after in replacements:text=text.replace(before,after)
    writer=PdfWriter();page=writer.add_blank_page(width=595,height=842)
    font=DictionaryObject({NameObject('/Type'):NameObject('/Font'),NameObject('/Subtype'):NameObject('/Type1'),NameObject('/BaseFont'):NameObject('/Helvetica')})
    page[NameObject('/Resources')]=DictionaryObject({NameObject('/Font'):DictionaryObject({NameObject('/F1'):writer._add_object(font)})})
    lines=[line.replace('\\','\\\\').replace('(','\\(').replace(')','\\)') for line in text.splitlines()]
    stream=DecodedStreamObject();stream.set_data(('BT /F1 10 Tf 14 TL 40 790 Td '+''.join('('+line+') Tj T* ' for line in lines)+'ET').encode())
    page[NameObject('/Contents')]=writer._add_object(stream);result=BytesIO();writer.write(result);return result.getvalue()


def request(origin,path,payload=None,headers=None):
    req=urllib.request.Request(origin+path,data=json.dumps(payload).encode() if payload is not None else None,headers=headers or {})
    try:
        with urllib.request.urlopen(req,timeout=5) as response:
            body=response.read()
            return response.status,json.loads(body) if response.headers.get_content_type()=='application/json' else body
    except urllib.error.HTTPError as exc:return exc.code,json.load(exc)


class LedgerTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.ledger=Ledger(Path(self.temp.name)/'test.sqlite3')
        self.reference=json.loads((ROOT/'fixtures/reference.json').read_text());self.ledger.import_reference(self.reference)
    def tearDown(self):self.temp.cleanup()
    def process(self,name,blob=None):
        result=self.ledger.process(blob or (ROOT/'output/pdf'/f'invoice-{name}.pdf').read_bytes(),name+'.pdf')
        return next(i for i in self.ledger.state()['invoices'] if i['id']==result['id'])
    def codes(self,record):return {i['code'] for i in record['result']['issues']}

    def test_clear_and_source_evidence(self):
        record=self.process('clear');self.assertEqual(record['status'],'clear')
        self.assertTrue(record['result']['reserved'])
        for source in record['document']['evidence'].values():
            self.assertEqual(source['page'],1);self.assertGreater(source['line'],0);self.assertTrue(source['text'])

    def test_price_variance_decimal_and_locale(self):
        record=self.process('price');self.assertEqual(self.codes(record),{'PRICE_VARIANCE'})
        self.assertEqual(record['result']['price_variance'],'180.00')
        self.assertEqual(record['document']['fields']['total'],'1944.00')
        self.assertTrue(record['result']['reserved'])

    def test_partial_receipt_quantity(self):
        record=self.process('quantity');self.assertEqual(self.codes(record),{'RECEIPT_QUANTITY'})
        self.assertEqual(record['result']['issues'][0]['excess'],'4.00')

    def test_cumulative_quantity_survives_restart(self):
        self.assertEqual(self.process('cumulative-first')['status'],'clear')
        self.ledger=Ledger(Path(self.temp.name)/'test.sqlite3')
        second=self.process('cumulative-second')
        self.assertEqual(self.codes(second),{'ORDER_QUANTITY','RECEIPT_QUANTITY'})
        self.assertEqual(Decimal(second['result']['matches'][0]['previous_quantity']),Decimal(6))
        self.assertEqual(Decimal(second['result']['matches'][0]['cumulative_quantity']),Decimal(11))

    def test_semantic_duplicate_does_not_reserve(self):
        self.process('clear');duplicate=self.process('duplicate')
        self.assertEqual(self.codes(duplicate),{'DUPLICATE_IDENTIFIER'})
        self.assertFalse(duplicate['result']['reserved'])
        with self.ledger.connect() as db:
            quantities=[Decimal(r[0]) for r in db.execute('SELECT quantity FROM claims WHERE po_id=\'PO-2101\'')]
        self.assertEqual(sum(quantities),Decimal(10))

    def test_identifier_with_changed_content_is_held(self):
        blob=(ROOT/'output/pdf/invoice-clear.pdf').read_bytes();self.process('clear')
        record=self.process('changed',changed_pdf(blob,[('480.00','500.00')]))
        self.assertIn('CONFLICTING_IDENTIFIER',self.codes(record));self.assertFalse(record['result']['reserved'])

    def test_same_content_new_number_is_only_suspected_duplicate(self):
        blob=(ROOT/'output/pdf/invoice-clear.pdf').read_bytes();self.process('clear')
        record=self.process('new-number',changed_pdf(blob,[('INV-2401','INV-9999')]))
        self.assertEqual(self.codes(record),{'POSSIBLE_DUPLICATE'});self.assertFalse(record['result']['reserved'])

    def test_repeated_field_never_passes(self):
        blob=(ROOT/'output/pdf/invoice-clear.pdf').read_bytes()
        record=self.process('ambiguous',changed_pdf(blob,[('Currency: EUR','Currency: EUR\nCurrency: USD')]))
        self.assertIn('AMBIGUOUS_FIELD',self.codes(record));self.assertFalse(record['result']['reserved'])

    def test_concurrent_exact_replays_atomic(self):
        blob=(ROOT/'output/pdf/invoice-clear.pdf').read_bytes()
        with ThreadPoolExecutor(max_workers=8) as pool:
            results=list(pool.map(lambda _:self.ledger.process(blob,'same.pdf'),range(24)))
        self.assertEqual(sum(not r['repeat'] for r in results),1)
        self.assertEqual(self.ledger.state()['metrics']['processed'],1)
        with self.ledger.connect() as db:self.assertEqual(db.execute('SELECT COUNT(*) FROM claims').fetchone()[0],1)

    def test_currency_mismatch_no_conversion_or_claim(self):
        record=self.process('currency');self.assertEqual(self.codes(record),{'CURRENCY_MISMATCH'})
        self.assertFalse(record['result']['reserved'])

    def test_invalid_total_no_claim(self):
        record=self.process('total');self.assertEqual(self.codes(record),{'TOTAL_MISMATCH'})
        self.assertFalse(record['result']['reserved'])

    def test_missing_is_not_classified_as_mismatch(self):
        record=self.process('missing');self.assertEqual(self.codes(record),{'MISSING_FIELD'})
        self.assertFalse(record['result']['reserved'])

    def test_textless_and_damaged_documents_never_clear(self):
        for name,blob,code in [('scan',None,'NO_TEXT_FIELDS'),('damaged',b'%PDF-1.7 broken','UNREADABLE_DOCUMENT')]:
            record=self.process(name,blob);self.assertEqual(record['status'],'review')
            self.assertEqual(self.codes(record),{code});self.assertFalse(record['result']['reserved'])

    def test_encrypted_document_needs_manual_extraction(self):
        writer=PdfWriter();writer.add_page(PdfReader(ROOT/'output/pdf/invoice-clear.pdf').pages[0]);writer.encrypt('test-only-password')
        stream=BytesIO();writer.write(stream)
        self.assertEqual(self.codes(self.process('encrypted',stream.getvalue())),{'UNREADABLE_DOCUMENT'})

    def test_reference_import_atomic_and_immutable(self):
        altered=deepcopy(self.reference);altered['purchase_orders'][0]['items'][0]['quantity']='99'
        with self.assertRaises(InputError):self.ledger.import_reference(altered)
        self.assertEqual(self.ledger.state()['orders'][0]['items'][0]['quantity'],'100')
        altered=deepcopy(self.reference);altered['receipts'][0]['items'][0]['sku']=[]
        with self.assertRaises(InputError):self.ledger.import_reference(altered)

    def test_money_and_ambiguous_numbers(self):
        self.assertEqual(decimal('1.234,50','de-DE',True),Decimal('1234.50'))
        self.assertEqual(decimal('1,234.50','en-US',True),Decimal('1234.50'))
        self.assertEqual(money(Decimal('0.005')),'0.01')
        for value in ('NaN','Infinity','-1','1,23','1e3','0.001'):
            with self.assertRaises(InputError):decimal(value,'en-US',True)


class EvaluationTests(unittest.TestCase):
    def test_fixed_synthetic_layout_evaluation(self):
        for case in json.loads((ROOT/'fixtures/evaluation.json').read_text()):
            with self.subTest(pdf=case['pdf']),tempfile.TemporaryDirectory() as directory:
                ledger=Ledger(Path(directory)/'eval.sqlite3');ledger.import_reference(case['reference'])
                ledger.process((ROOT/case['pdf']).read_bytes(),'evaluation.pdf')
                record=ledger.state()['invoices'][0];expected=case['truth']
                for key,value in record['document']['fields'].items():self.assertEqual(value,expected[key])
                self.assertEqual(set(record['document']['fields']),set(expected)-{'items'})
                for observed,truth in zip(record['document']['items'],expected['items']):
                    for key in ('sku','description'):self.assertEqual(observed[key],truth[key])
                    for key in ('quantity','unit_price','amount'):self.assertEqual(Decimal(observed[key]),Decimal(truth[key]))
                self.assertEqual(len(record['document']['items']),len(expected['items']))
                self.assertEqual({p['code'] for p in record['result']['issues']},set(case['expected_codes']))
                self.assertEqual(record['status'],'review' if case['expected_codes'] else 'clear')


class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.server=make_server(self.temp.name)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.origin=f'http://127.0.0.1:{self.server.server_port}';self.headers={'X-Guard-Control':self.server.app.token}
    def tearDown(self):self.server.shutdown();self.server.server_close();self.temp.cleanup()
    def test_upload_export_and_original_document(self):
        blob=(ROOT/'output/pdf/invoice-price.pdf').read_bytes()
        code,result=request(self.origin,'/api/upload',{'filename':'price.pdf','pdf_base64':base64.b64encode(blob).decode()},self.headers)
        self.assertEqual(code,202);self.assertEqual(request(self.origin,f'/documents/{result["id"]}.pdf')[1],blob)
        exported=request(self.origin,'/api/export')[1];self.assertEqual(exported['metrics']['review'],1)
        self.assertEqual(exported['metrics']['price_variances']['EUR'],'180.00')
    def test_control_and_input_boundaries(self):
        self.assertEqual(request(self.origin,'/api/demo',{'mode':'price'})[0],403)
        self.assertEqual(request(self.origin,'/api/state',headers={'Origin':'https://evil.example'})[0],403)
        self.assertEqual(request(self.origin,'/api/state',headers={'Host':'evil.example'})[0],403)
        self.assertEqual(request(self.origin,'/api/demo',{'mode':[]},self.headers)[0],400)
        self.assertEqual(request(self.origin,'/api/upload',{'pdf_base64':'invalid!!'},self.headers)[0],400)
        self.assertEqual(request(self.origin,'/api/reference',{'purchase_orders':[],'receipts':[]},self.headers)[0],400)


if __name__=='__main__':unittest.main(verbosity=2)
